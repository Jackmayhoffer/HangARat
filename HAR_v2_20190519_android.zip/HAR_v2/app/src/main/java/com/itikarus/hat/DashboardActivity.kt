package com.itikarus.hat

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.widget.Toast
import com.itikarus.hangaratlib.BluetoothService
import com.itikarus.hangaratlib.Devicetransfer
import com.itikarus.hat.api.ApiClient
import com.itikarus.hat.library.utils.DialogUtils
import com.itikarus.hat.model.ResBase
import com.itikarus.hat.model.SavedPostValue
import com.itikarus.hat.model.SigninInfo
import com.robinhood.ticker.TickerUtils
import kotlinx.android.synthetic.main.layout_dashboard.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import kotlin.collections.HashMap

class DashboardActivity : MainActivity() {

    private enum class Status{
        NOTHING,
        RECEVING,
        FROZEN
    }

    override fun getScreenTitle(): String {
        return "Ratboard"
    }

    override fun getPageLayoutId(): Int {
        return R.layout.layout_dashboard
    }

    private var lastValue = "0.000"
    private var currentValue = "0.000"
    private var status : Status = Status.NOTHING
    private var lastCheckedTime = 0.toLong()
    private val threadHandler = Handler()
    private val runnableCode = object: Runnable {
        override fun run() {
            val currentTime = System.currentTimeMillis()

            if(currentTime - lastCheckedTime > (2 * 1000)){ // per 3 seconds, check
                lastCheckedTime = currentTime

                if(lastValue.toFloat() > 0 && currentValue.toFloat() > 0 && lastValue == currentValue) {
                    status = Status.FROZEN
                    SavedPostValue.build(this@DashboardActivity).savedValue = currentValue
                    runOnUiThread {
                        notifyResetBtnStatus()
                        notifyPostBtnStatus()
                    }
                }else{
                    lastValue = currentValue
                }

            }
            threadHandler.postDelayed(this, 300)
        }
    }

    private var tempValue = 0.00

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        tv_tickerView.setCharacterLists(TickerUtils.provideNumberList())

        if(BluetoothService.getState() == BluetoothService.STATE_CONNECTED){
            BluetoothService.setup(mHandler, this)

        }

        iv_btnRefresh.setOnClickListener {
            restartActivity(ScanActivity::class.java)
        }

        btn_post.setOnClickListener {
//            tempValue += 235.235
//            tv_tickerView.text = tempValue.toString()
//            uploadValue()

            if(isAvailableToPost()){
                DialogUtils.showOkayNoDialog(this, getString(R.string.app_name),
                    //"Your current weight is ${SavedPostValue.build(this@DashboardActivity).savedValue}.\nWill you post this weight?",
                    "Post your results?",
                    object : DialogUtils.OnOkayNoEvent{
                    override fun onOkay() {

                    }

                    override fun onNo() {
                        checkAuth { uploadValue() }
                    }
                })
            }
        }

        btn_reset.setOnClickListener {
            reset()
        }

        BluetoothService.dataReceived = {
            runOnUiThread {
                if(status == Status.FROZEN) return@runOnUiThread

                currentValue = it
                tv_tickerView.text = currentValue
                status = Status.RECEVING
                notifyPostBtnStatus()
            }
        }



        Handler().postDelayed({
            if(isConnectedDevice()){
                threadHandler.postDelayed(runnableCode, 1000)
            }
        }, 1000)

        notifyPostBtnStatus()

        tv_tickerView.text = SavedPostValue.build(this).savedValue
    }

    private fun uploadValue(){
        val params = HashMap<String, String>()
        params["AccessToken"] = SigninInfo.build(this).accessToken
        params["Value"] = tv_tickerView.text

        showProgressDialog("Posting...")
        val call = ApiClient.apiClient!!.sendValue(params)
        call.enqueue(object : Callback<ResBase>{

            override fun onFailure(call: Call<ResBase>, t: Throwable) {
                hideProgressDialog()
                t.printStackTrace()
                DialogUtils.showOkayDialog(this@DashboardActivity, getString(R.string.app_name), t.message)
            }

            override fun onResponse(call: Call<ResBase>, response: Response<ResBase>) {
                hideProgressDialog()
                if(response.body()!!.errorCode == 0){
                    DialogUtils.showOkayDialog(this@DashboardActivity, getString(R.string.app_name), "Post Complete"){
                        SavedPostValue.build(this@DashboardActivity).clear()
                        reset()
                        notifyPostBtnStatus()
                    }
                }  else{
                    DialogUtils.showOkayDialog(this@DashboardActivity, getString(R.string.app_name), response.body()!!.errorMsg)
                }
            }

        })

    }

    private fun reset(){
        status = Status.NOTHING
        currentValue = "0.000"
        lastValue = "0.000"
        tv_tickerView.text = currentValue
        notifyResetBtnStatus()
    }

    private fun notifyResetBtnStatus(){
        if(status == Status.FROZEN){
            btn_reset.setBackgroundResource(R.drawable.background_outline)
            tv_labelReset.setTextColor(resources.getColor(R.color.light_gray))
        }else{
            btn_reset.setBackgroundResource(R.drawable.background_outline_gray)
            tv_labelReset.setTextColor(Color.parseColor("#55909090"))
        }
    }

    private fun isAvailableToPost() : Boolean{
        return SavedPostValue.build(this).hasValidValue() && status != Status.RECEVING
    }

    private fun notifyPostBtnStatus(){
        if(isAvailableToPost()){
            btn_post.setBackgroundResource(R.drawable.background_outline)
            tv_labelPostIt.setTextColor(resources.getColor(R.color.light_gray))
        }else{
            btn_post.setBackgroundResource(R.drawable.background_outline_gray)
            tv_labelPostIt.setTextColor(Color.parseColor("#55909090"))
        }
    }

    @SuppressLint("HandlerLeak")
    private val mHandler = object : Handler() {

        override fun handleMessage(msg: Message) {
            //JQuery.e("GOT MESSAGE:::: " + msg.what)
            when (msg.what) {
                Devicetransfer.MESSAGE_STATE_CHANGE -> {
                    //JQuery.e("MESSAGE_STATE_CHANGE: " + msg.arg1)
                    when (msg.arg1) {
                        BluetoothService.STATE_CONNECTED -> {
                        }
                        BluetoothService.STATE_CONNECTING -> {
                        }
                        BluetoothService.STATE_LISTEN, BluetoothService.STATE_NONE -> {
                        }
                    }
                }
                Devicetransfer.MESSAGE_WRITE -> {
                }
                Devicetransfer.MESSAGE_READ -> {
                }
                Devicetransfer.MESSAGE_DEVICE_NAME -> {
                    Toast.makeText(
                        applicationContext,
                        "Connected to " + msg.data.getString(Devicetransfer.DEVICE_NAME)!!,
                        Toast.LENGTH_LONG
                    ).show()
                    hideProgressDialog()
                    restartActivity(DashboardActivity::class.java)
                }
                Devicetransfer.MESSAGE_TOAST,

                Devicetransfer.MESSAGE_UNABLE_TO_CONNECT -> {

                    //JQuery.d("UNABLE TO CONNECT")
                    if (BluetoothService.getState() != BluetoothService.STATE_CONNECTED) {
                        BluetoothService.setForceStopped(true)
                        Toast.makeText(applicationContext, msg.data.getString(Devicetransfer.TOAST), Toast.LENGTH_LONG)
                            .show()
                        hideProgressDialog()
                    }
                }

                Devicetransfer.MESSAGE_BLUETOOTH_ERROR -> Toast.makeText(
                    applicationContext,
                    "BLUETOOTH ERROR",
                    Toast.LENGTH_SHORT
                ).show()

                Devicetransfer.MESSAGE_DISTOERROR -> Toast.makeText(
                    applicationContext,
                    "DISTO ERROR",
                    Toast.LENGTH_SHORT
                ).show()

                Devicetransfer.MESSAGE_KEYBOARD -> Toast.makeText(
                    applicationContext,
                    "KEYBOARD ERROR",
                    Toast.LENGTH_SHORT
                ).show()

                Devicetransfer.MESSAGE_CHARACTERISTIC_READ -> {
//                    val value = msg.arg1/1000f
//                    tv_tickerView.text = value.toString()
                }
            }
        }
    }
}
