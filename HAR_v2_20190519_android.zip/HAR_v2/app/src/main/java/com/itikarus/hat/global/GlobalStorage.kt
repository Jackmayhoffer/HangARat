package com.itikarus.hat.global

object GlobalStorage {
    var actionAfterSignin : (() -> Unit)? = null

    val isDebugMode = false
}