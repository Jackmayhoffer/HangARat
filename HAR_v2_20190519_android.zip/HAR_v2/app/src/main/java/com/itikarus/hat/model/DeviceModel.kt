package com.itikarus.hat.model

import android.bluetooth.BluetoothDevice
import android.text.TextUtils

class DeviceModel {
    var deviceName : String? = null
        get() {
            if (TextUtils.isEmpty(field)) this.deviceName = "Unknown"
            return field
        }
    var deviceAddress : String? = null
        get() {
            if (TextUtils.isEmpty(field)) this.deviceAddress = "Unknown"
            return field
        }

    var bluetoothDevice: BluetoothDevice? = null
    var isSelected = false
}
