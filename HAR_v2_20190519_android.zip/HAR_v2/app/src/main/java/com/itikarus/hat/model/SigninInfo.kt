package com.itikarus.hat.model

import android.content.Context
import com.itikarus.hat.library.utils.TinyDB

class SigninInfo(context: Context) {

    var username = ""
        set(username) {
            field = username
            update()
        }
    var password = ""
        set(password) {
            field = password
            update()
        }
    var accessToken = ""
    set(value) {
        field = value
        update()
    }

    var userId = ""
        set(value) {
            field = value
            update()
        }

    init {
        mDB = TinyDB(context)
    }

    fun update() {
        mDB!!.putObject(LOGIN_DATA, this)
    }

    fun clear() {
        username = ""
        password = ""
        accessToken = ""
        update()
    }

    fun hasAuth() : Boolean{
        return accessToken.isNotEmpty()
    }

    companion object {

        private val LOGIN_DATA = "login_info"

        private var mDB: TinyDB? = null

        fun build(context: Context): SigninInfo {
            mDB = TinyDB(context)
            try {
                return mDB!!.getObject(LOGIN_DATA, SigninInfo::class.java) as SigninInfo
            } catch (e: NullPointerException) {
                return SigninInfo(context)
            }

        }
    }
}
