package com.itikarus.hat

import android.os.Bundle

class TermsAndPolicyActivity : MainActivity() {
    override fun getScreenTitle(): String {
        return "Terms of Service"
    }

    override fun getPageLayoutId(): Int {
        return R.layout.activity_terms_and_policy
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }
}
