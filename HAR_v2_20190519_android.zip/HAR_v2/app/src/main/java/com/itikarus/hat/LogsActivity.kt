package com.itikarus.hat

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.itikarus.hat.api.ApiClient
import com.itikarus.hat.library.utils.DialogUtils
import com.itikarus.hat.model.ResBase
import com.itikarus.hat.model.ResGetValue
import com.itikarus.hat.model.SigninInfo
import com.itikarus.hat.model.ValueModel
import kotlinx.android.synthetic.main.activity_logs.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LogsActivity : MainActivity() {

    private var models = ArrayList<ValueModel>()
    private lateinit var mAdapter : LogListAdapter

    override fun getScreenTitle(): String {
        return "Personal Stats"
    }

    override fun getPageLayoutId(): Int {
        return R.layout.activity_logs
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mAdapter = LogListAdapter()

        lv_logList.adapter = mAdapter

        tv_btnClear.setOnClickListener {
            clearWeights()
        }

        loadData()
    }

    private inner class LogListAdapter : BaseAdapter(){

        private var inflater : LayoutInflater? = null

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view : View
            val cvh : CustomViewHolder
            if(inflater == null) inflater = layoutInflater

            if(convertView == null){
                view = inflater!!.inflate(R.layout.item_log, parent, false)
                cvh = CustomViewHolder(view)
                view.tag = cvh
            }else{
                view = convertView
                cvh = view.tag as CustomViewHolder
            }

            val item = getItem(position)
            with(cvh){
                noViewer.text = (position + 1).toString()
                timeViewer.text = item.createdDt
                valueViewer.text = String.format("%.3f", item.value)
            }

            return view
        }

        override fun getItem(position: Int): ValueModel {
            return models[position]
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getCount(): Int {
            return models.size
        }

        inner class CustomViewHolder(view : View){
            val noViewer = view.findViewById<View>(R.id.tv_noViewer) as TextView
            val timeViewer = view.findViewById<View>(R.id.tv_timeViewer) as TextView
            val valueViewer = view.findViewById<View>(R.id.tv_valueViewer) as TextView
        }

    }

    private fun loadData(){
        val params = HashMap<String, String>()
        params["AccessToken"] = SigninInfo.build(this).accessToken
        params["Mode"] = "INDIVIDUAL"

        showProgressDialog("Wait...")
        val call = ApiClient.apiClient!!.getValue(params)
        call.enqueue(object : Callback<ResGetValue> {
            override fun onFailure(call: Call<ResGetValue>, t: Throwable) {
                hideProgressDialog()
                t.printStackTrace()
                DialogUtils.showOkayDialog(this@LogsActivity, getString(R.string.app_name), t.message)
            }

            override fun onResponse(call: Call<ResGetValue>, response: Response<ResGetValue>) {
                hideProgressDialog()
                if(response.body()!!.errorCode == 0){
                    models = response.body()!!.values
                    mAdapter.notifyDataSetChanged()
                }  else{
                    DialogUtils.showOkayDialog(this@LogsActivity, getString(R.string.app_name), response.body()!!.errorMsg)
                }
            }
        })
    }

    private fun clearWeights(){
        val params = HashMap<String, String>()
        params["AccessToken"] = SigninInfo.build(this).accessToken

        showProgressDialog("Clearing...")
        val call = ApiClient.apiClient!!.clearWeights(params)
        call.enqueue(object : Callback<ResBase> {
            override fun onFailure(call: Call<ResBase>, t: Throwable) {
                hideProgressDialog()
                t.printStackTrace()
                DialogUtils.showOkayDialog(this@LogsActivity, getString(R.string.app_name), t.message)
            }

            override fun onResponse(call: Call<ResBase>, response: Response<ResBase>) {
                hideProgressDialog()
                if(response.body()!!.errorCode == 0){
                    models.clear()
                    mAdapter.notifyDataSetChanged()
                }  else{
                    DialogUtils.showOkayDialog(this@LogsActivity, getString(R.string.app_name), response.body()!!.errorMsg)
                }
            }
        })
    }
}
