package com.itikarus.hat

import android.os.Bundle

class FAQActivity : MainActivity() {
    override fun getScreenTitle(): String {
        return "FAQ"
    }

    override fun getPageLayoutId(): Int {
        return R.layout.activity_faq
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
}
