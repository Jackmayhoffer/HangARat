package com.itikarus.hat

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import com.itikarus.hat.api.ApiClient
import com.itikarus.hat.base.BaseActivity
import com.itikarus.hat.library.utils.DialogUtils
import com.itikarus.hat.model.ResSignup
import com.itikarus.hat.model.SigninInfo
import kotlinx.android.synthetic.main.activity_sign_up.*
import kotlinx.android.synthetic.main.layout_header.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.HashMap

class SignUpActivity : BaseActivity() {

    private var showPwStatus = false

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        tv_titleViewer.text = "SignUp"

        arrayOf(iv_btnSignIn, iv_btnSignUp, rl_btnEye, iv_btnBack).forEach {
            it.setOnClickListener { view ->
                when(view.id){
                    R.id.iv_btnSignIn->{
                        onBackPressed()
                    }
                    R.id.iv_btnSignUp->{
                        val out = Out<String>()
                        if(!checkEditText(et_userName, out))return@setOnClickListener
                        val username = out.get()!!
                        if(!checkEmail(et_Email, out)) return@setOnClickListener
                        val email = out.get()!!
                        if(!checkEditText(et_password, out))return@setOnClickListener
                        val password = out.get()!!
                        if(!checkEditText(et_passwordAgain, out)) return@setOnClickListener
                        val passwordAgain = out.get()!!
                        if(password != passwordAgain){
                            et_passwordAgain.error = "Not matched"
                            return@setOnClickListener
                        }
                        signUp(username, email, password)
                    }
                    R.id.rl_btnEye->{
                        if(showPwStatus){
                            hidePwContent()
                        }else{
                            showPwContent()
                        }
                    }
                    R.id.iv_btnBack->{
                        onBackPressed()
                    }
                }
            }
        }
    }

    private fun showPwContent() {
        showPwStatus = !showPwStatus
        iv_eyeIcon.setImageResource(R.drawable.ic_eye_hidden)
        et_password.transformationMethod = HideReturnsTransformationMethod.getInstance()
        et_password.setSelection(et_password.text.length)
        et_passwordAgain.transformationMethod = HideReturnsTransformationMethod.getInstance()
        et_passwordAgain.setSelection(et_passwordAgain.text.length)
    }

    private fun hidePwContent() {
        showPwStatus = !showPwStatus
        iv_eyeIcon.setImageResource(R.drawable.ic_eye_show)
        et_password.transformationMethod = PasswordTransformationMethod.getInstance()
        et_password.setSelection(et_password.text.length)
        et_passwordAgain.transformationMethod = PasswordTransformationMethod.getInstance()
        et_passwordAgain.setSelection(et_passwordAgain.text.length)

    }

    override fun onBackPressed() {
        finish()
    }

    private fun signUp(userName : String, email : String, password : String){
        showProgressDialog("SignUp..")

        val params = HashMap<String, String>()
        params["UserName"] = userName
        params["Password"] = password
        params["Email"] = email

        val call : Call<ResSignup> = ApiClient.apiClient!!.signup(params)
        call.enqueue(object : Callback<ResSignup> {
            override fun onFailure(call: Call<ResSignup>, t: Throwable) {
                hideProgressDialog()
                t.printStackTrace()
                DialogUtils.showOkayDialog(this@SignUpActivity, getString(R.string.app_name), t.message)
            }

            override fun onResponse(call: Call<ResSignup>, response: Response<ResSignup>) {
                hideProgressDialog()
                if(response.body()!!.errorCode == 0){
                    val userModel = response.body()!!.userModel
                    SigninInfo.build(this@SignUpActivity).userId = userModel.userId
                    SigninInfo.build(this@SignUpActivity).username = userModel.userName
                    SigninInfo.build(this@SignUpActivity).password = password
                    SigninInfo.build(this@SignUpActivity).accessToken = response.body()!!.accessToken
                    setResult(Activity.RESULT_OK)
                    finish()
                }else{
                    DialogUtils.showOkayDialog(this@SignUpActivity, getString(R.string.app_name), response.body()!!.errorMsg)
                }
            }
        })
    }
}
