package com.itikarus.hat

import android.os.Bundle

class FeedbackActivity : MainActivity() {
    override fun getScreenTitle(): String {
        return "Feedback"
    }

    override fun getPageLayoutId(): Int {
        return R.layout.activity_feedback
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }
}
