package com.itikarus.hat

import android.os.Bundle
import android.os.Handler
import com.itikarus.hat.base.BaseActivity

class SplashActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        Handler().postDelayed({
            restartActivity(ScanActivity::class.java)
        }, 2000)
    }
}
