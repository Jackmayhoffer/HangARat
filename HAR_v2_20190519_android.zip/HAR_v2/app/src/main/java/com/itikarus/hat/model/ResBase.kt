package com.itikarus.hat.model

import com.google.gson.annotations.SerializedName

open class ResBase {
    @SerializedName("AccessToken")
    var accessToken = ""
    @SerializedName("ErrorCode")
    var errorCode = -1
    @SerializedName("ErrorMessage")
    var errorMsg = ""
}