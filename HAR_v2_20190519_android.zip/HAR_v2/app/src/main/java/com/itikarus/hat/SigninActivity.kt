package com.itikarus.hat

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import com.itikarus.hat.api.ApiClient
import com.itikarus.hat.global.GlobalStorage
import com.itikarus.hat.global.IntentUtil
import com.itikarus.hat.library.utils.DialogUtils
import com.itikarus.hat.model.ResSignup
import com.itikarus.hat.model.SigninInfo
import kotlinx.android.synthetic.main.activity_signin.*
import kotlinx.android.synthetic.main.layout_drawer.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SigninActivity : MainActivity() {

    private var showPwStatus = false
    override fun getScreenTitle(): String {
        return "Sign in"
    }

    override fun getPageLayoutId(): Int {
        return R.layout.activity_signin
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arrayOf(iv_btnSignIn, iv_btnSignUp, rl_btnEye, tv_forgotPassword).forEach {
            it.setOnClickListener {view->
                when(view.id){
                    R.id.iv_btnSignIn->{
                        val out = Out<String>()
                        if(!checkEditText(et_UserName, out)) return@setOnClickListener
                        val usernameOrEmail = out.get()!!
                        if(!checkEditText(et_password, out)) return@setOnClickListener
                        val password = out.get()!!

                        signIn(usernameOrEmail, password)
                    }
                    R.id.iv_btnSignUp->{
                        val intent = Intent(this, SignUpActivity::class.java)
                        startActivityForResult(intent, 1001)
                    }
                    R.id.rl_btnEye->{
                        if(showPwStatus){
                            hidePwContent()
                        }else{
                            showPwContent()
                        }
                    }
                    R.id.tv_forgotPassword->{
                        startActivity(ForgotPasswordActivity::class.java)
                    }
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if(requestCode == 1001 && resultCode == Activity.RESULT_OK){
            next()
        }
    }

    private fun next(){
        setResult(Activity.RESULT_OK)
        finish()
    }

    private fun signIn(usernameOrEmail : String, password : String){
        showProgressDialog("Signin...")

        val params = HashMap<String, String>()
        params["UserName"] = usernameOrEmail
        params["Password"] = password
        params["Device"] = "Android"
        params["Version"] = "1.0.0"

        val call : Call<ResSignup> = ApiClient.apiClient!!.signin(params)
        call.enqueue(object : Callback<ResSignup> {
            override fun onFailure(call: Call<ResSignup>, t: Throwable) {
                hideProgressDialog()
                t.printStackTrace()
                DialogUtils.showOkayDialog(this@SigninActivity, getString(R.string.app_name), t.message)
            }

            override fun onResponse(call: Call<ResSignup>, response: Response<ResSignup>) {
                hideProgressDialog()
                if(response.body()!!.errorCode == 0){
                    val userModel = response.body()!!.userModel
                    SigninInfo.build(this@SigninActivity).userId = userModel.userId
                    SigninInfo.build(this@SigninActivity).username = userModel.userName
                    SigninInfo.build(this@SigninActivity).password = password
                    SigninInfo.build(this@SigninActivity).accessToken = response.body()!!.accessToken
                    tv_linkLogin.text = "Logout"
                    next()
                }  else{
                    DialogUtils.showOkayDialog(this@SigninActivity, getString(R.string.app_name), response.body()!!.errorMsg)
                }
            }
        })

    }

    private fun showPwContent() {
        showPwStatus = !showPwStatus
        iv_eyeIcon.setImageResource(R.drawable.ic_eye_hidden)
        et_password.transformationMethod = HideReturnsTransformationMethod.getInstance()
        et_password.setSelection(et_password.text.length)
    }

    private fun hidePwContent() {
        showPwStatus = !showPwStatus
        iv_eyeIcon.setImageResource(R.drawable.ic_eye_show)
        et_password.transformationMethod = PasswordTransformationMethod.getInstance()
        et_password.setSelection(et_password.text.length)
    }
}
