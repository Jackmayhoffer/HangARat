package com.itikarus.hat.global

class IntentUtil {
    companion object {
        val KEY_INTENT_FROM = "from"
    }
}