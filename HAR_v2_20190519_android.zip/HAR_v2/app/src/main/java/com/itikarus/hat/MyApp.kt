package com.itikarus.hat

import android.content.Context
import android.support.multidex.MultiDex
import android.support.multidex.MultiDexApplication
import com.nostra13.universalimageloader.cache.disc.impl.ext.LruDiscCache
import com.nostra13.universalimageloader.cache.disc.naming.HashCodeFileNameGenerator
import com.nostra13.universalimageloader.cache.memory.impl.UsingFreqLimitedMemoryCache
import com.nostra13.universalimageloader.core.DisplayImageOptions
import com.nostra13.universalimageloader.core.ImageLoader
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration
import com.nostra13.universalimageloader.utils.StorageUtils
import com.orm.SugarContext
import java.io.IOException


class MyApp : MultiDexApplication() {

    override fun attachBaseContext(context: Context) {
        super.attachBaseContext(context)
        MultiDex.install(this)
    }

    override fun onTerminate() {
        super.onTerminate()
        SugarContext.terminate()
    }

    override fun onCreate() {
        super.onCreate()

        SugarContext.init(this)
    }

    init {
        mInstance = this
    }

    companion object {
        private var mInstance : MyApp? = null

    }

}
