package com.itikarus.hat


import android.os.Bundle

class SettingsActivity : MainActivity() {
    override fun getScreenTitle(): String {
        return "Settings"
    }

    override fun getPageLayoutId(): Int {
        return R.layout.activity_settings
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
}
