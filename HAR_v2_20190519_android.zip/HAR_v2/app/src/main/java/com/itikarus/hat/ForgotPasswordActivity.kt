package com.itikarus.hat

import android.os.Bundle
import android.view.View
import android.widget.EditText
import com.itikarus.hat.api.ApiClient
import com.itikarus.hat.base.BaseActivity
import com.itikarus.hat.library.utils.DialogUtils
import com.itikarus.hat.model.ResBase
import kotlinx.android.synthetic.main.activity_forgot_password.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ForgotPasswordActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)

        btnBack.setOnClickListener {
            onBackPressed()
        }

        btnSendPw.setOnClickListener {
            val out = Out<String>()
            if (!checkEmail(findViewById<View>(R.id.etEmail) as EditText, out)) return@setOnClickListener
            val email = out.get()
            forgotPassword(email!!)
        }
    }

    override fun onBackPressed() {
        finish()
    }

    private fun forgotPassword(email : String){
        val params = HashMap<String, String>()
        params["Email"] = email

        showProgressDialog("Requesting new password...")
        val call = ApiClient.apiClient!!.forgotPassword(params)
        call.enqueue(object : Callback<ResBase> {
            override fun onFailure(call: Call<ResBase>, t: Throwable) {
                hideProgressDialog()
                t.printStackTrace()
                DialogUtils.showOkayDialog(this@ForgotPasswordActivity, getString(R.string.app_name), t.message)
            }

            override fun onResponse(call: Call<ResBase>, response: Response<ResBase>) {
                hideProgressDialog()
                if(response.body() != null){
                    DialogUtils.showOkayDialog(this@ForgotPasswordActivity, getString(R.string.app_name), response.body()!!.errorMsg)
                }
            }
        })

    }
}
