package com.itikarus.hat

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.view.animation.*
import com.itikarus.hat.base.BaseActivity
import com.itikarus.hat.global.GlobalStorage
import com.itikarus.hat.library.utils.DialogUtils
import kotlinx.android.synthetic.main.activity_scan.*


class ScanActivity : PermissionCheckActivity() {

    override fun requiredPermissions(): Array<String> {
        return arrayOf(
            Manifest.permission.BLUETOOTH,
            Manifest.permission.BLUETOOTH_ADMIN,
            //Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
    }

    private var isScanning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scan)

        arrayOf(iv_btnScan, ll_btnConnectLater).forEach {
            it.setOnClickListener {
                when(it.id){
                    R.id.iv_btnScan->{
                        permissionCheck {
                            if (BluetoothAdapter.getDefaultAdapter() != null){
                                val mBtAdapter = BluetoothAdapter.getDefaultAdapter()
                                if(!BluetoothAdapter.getDefaultAdapter()!!.isEnabled) {
                                    // Next Step
                                    mBtAdapter!!.enable()
                                }else{
                                    if(!isScanning) startScan()
                                    else stopScan()
                                }
                            }else{
                                DialogUtils.showOkayDialog(this@ScanActivity, "Sorry!", "Your Android device doesn't have bluetooth ability.") {finish()}
                            }
                        }
                    }
                    R.id.ll_btnConnectLater->{
                        //GlobalStorage.instance.isConnected = false
                        restartActivity(DashboardActivity::class.java)
                    }
                }
            }
        }

    }

    private fun startScan(){
        isScanning = true
        startScanAnimation()
        Handler(mainLooper).postDelayed({stopScan()}, 5000)
    }

    private fun stopScan(){
        isScanning = false
        stopScanAnimation()
        restartActivity(ConnectActivity::class.java)
    }


    private fun startScanAnimation(){
        iv_progressCircle.visibility = View.VISIBLE
        iv_progressStatus.setImageResource(R.drawable.ic_progress)
        rotateView(rl_rotateView)
    }

    private fun stopScanAnimation(){
        rl_rotateView.clearAnimation()
        iv_progressCircle.setImageResource(R.drawable.ic_turn)
    }

    private fun rotateView(view : View){
        val animSet = AnimationSet(true)
        animSet.interpolator = LinearInterpolator()
        animSet.fillAfter = true
        animSet.isFillEnabled = true

        val animRotate = RotateAnimation(0.0f, 359.0f,
                RotateAnimation.RELATIVE_TO_SELF, 0.5f,
                RotateAnimation.RELATIVE_TO_SELF, 0.5f)

        animRotate.duration = 3000
        animRotate.repeatCount = Animation.INFINITE
        animRotate.repeatMode = Animation.RESTART
        animRotate.fillAfter = true
        animSet.addAnimation(animRotate)

        view.startAnimation(animSet)
    }

}
