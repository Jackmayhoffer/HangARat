package com.itikarus.hat


import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.text.TextUtils
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.itikarus.hangaratlib.BluetoothService
import com.itikarus.hangaratlib.Devicetransfer
import com.itikarus.hat.base.BaseActivity
import com.itikarus.hat.library.utils.DialogUtils
import com.itikarus.hat.model.DeviceModel
import kotlinx.android.synthetic.main.activity_connect.*
import java.util.ArrayList

class ConnectActivity : BaseActivity() {

    //private val pairedDeviceListToShow = ArrayList<DeviceModel>()
    private val newDeviceListToShow = ArrayList<DeviceModel>()
    //private val pairedDeviceList = ArrayList<DeviceModel>()
    //private val newDeviceList = ArrayList<DeviceModel>()

    private lateinit var newDeviceListAdapter: DeviceListAdapter


    private var mBtAdapter: BluetoothAdapter? = null

    private var selectedDevice: DeviceModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_connect)

        newDeviceListAdapter = DeviceListAdapter(newDeviceListToShow)

        // Find and set up the ListView for newly discovered devices
        foundedDeviceList.adapter = newDeviceListAdapter
        setListViewHeightBasedOnChildren(foundedDeviceList)

        // Register for broadcasts when a device is discovered
        var filter = IntentFilter(BluetoothDevice.ACTION_FOUND)
        this.registerReceiver(mReceiver, filter)

        // Register for broadcasts when discovery has finished
        filter = IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        this.registerReceiver(mReceiver, filter)

        // Get the local Bluetooth adapter
        mBtAdapter = BluetoothAdapter.getDefaultAdapter()

        if(mBtAdapter == null) {
            Toast.makeText(this, getString(R.string.not_support_bluetooth), Toast.LENGTH_LONG).show()
            finish()
            return
        }

        btnPair.setOnClickListener {
            if (selectedDevice != null) {
                showProgressDialog(getString(R.string.connecting_hat))
                startPairing()
            } else {
                DialogUtils.showOkayDialog(this@ConnectActivity, getString(R.string.sorry), getString(R.string.select_device_pair))
            }
        }

        Handler(mainLooper).postDelayed({ scanDevice() }, 100)

        BluetoothService.init(this)
        BluetoothService.setup(mHandler, this)
        BluetoothService.setForceStopped(true)
    }

    private fun loadDeviceInfo() {
        // Get a set of currently paired devices
        val pairedDevices = mBtAdapter!!.bondedDevices
        var model: DeviceModel
        // If there are paired devices, add each one to the ArrayAdapter
        if (pairedDevices.size > 0) {
            for (device in pairedDevices) {
                model = DeviceModel()
                model.deviceName = device.name
                model.deviceAddress = device.address
                model.bluetoothDevice = device
                newDeviceListToShow.add(model)
                //pairedDeviceList.add(model)
            }
        } else {
            val noDevices = resources.getText(R.string.msg_none_paired).toString()

            model = DeviceModel()
            model.deviceName = noDevices
            //pairedDeviceListToShow.add(model)
        }

        doDiscovery()
    }

    private fun scanDevice() {

        if (!mBtAdapter!!.isEnabled) {
            // Next Step
            mBtAdapter!!.enable()
        }
        try {
            Thread.sleep(2000)
        } catch (e: InterruptedException) {
            e.printStackTrace()
            Handler(mainLooper).post { hideProgressDialog() }
        }

        hideProgressDialog()

        loadDeviceInfo()

    }

    private fun startPairing() {
        mBtAdapter?.cancelDiscovery()

        selectedDevice?.let {
            BluetoothService.init(this)
            BluetoothService.connectDevice(it.bluetoothDevice!!, this)
        }
    }

    private val mReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val action = intent.action
            val model: DeviceModel
            // When discovery finds a device
            if (BluetoothDevice.ACTION_FOUND == action) {
                // Get the BluetoothDevice object from the Intent
                val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                // If it's already paired, skip it, because it's been listed already
                if (device.bondState != BluetoothDevice.BOND_BONDED) {
                    model = DeviceModel()
                    model.deviceName = device.name
                    model.deviceAddress = device.address
                    model.bluetoothDevice = device
                    newDeviceListToShow.add(model)
                    newDeviceListAdapter.notifyDataSetChanged()
                }
                // When discovery is finished, change the Activity title
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED == action) {
                hideProgressDialog()
            }

            Handler().postDelayed({ newDeviceListAdapter.notifyDataSetChanged() }, 100)
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        // Make sure we're not doing discovery anymore
        mBtAdapter?.cancelDiscovery()

        // Unregister broadcast listeners
        try {
            unregisterReceiver(mReceiver)
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    private fun doDiscovery() {
        Log.d(TAG, "doDiscovery()")

        // Indicate scanning in the title
        showProgressDialog(getString(R.string.device_scanning))

        // If we're already discovering, stop it
        if (mBtAdapter!!.isDiscovering) {
            mBtAdapter!!.cancelDiscovery()
            showProgressDialog(getString(R.string.device_scanning))
        }

        // Request discover from BluetoothAdapter
        mBtAdapter!!.startDiscovery()
    }

    private inner class DeviceListAdapter(internal var deviceList: ArrayList<DeviceModel>) : BaseAdapter() {

        internal var inflater: LayoutInflater? = null

        override fun getCount(): Int {
            return deviceList.size
        }

        override fun getItem(i: Int): Any {
            return deviceList[i]
        }

        override fun getItemId(i: Int): Long {
            return i.toLong()
        }

        @SuppressLint("ViewHolder", "InflateParams")
        override fun getView(i: Int, convertView: View?, viewGroup: ViewGroup): View {
            if (inflater == null) inflater = layoutInflater

            val view = inflater!!.inflate(R.layout.item_pair_device, null)

            val model = getItem(i) as DeviceModel
            val str = model.deviceName
            val deviceNameViewer = view.findViewById<View>(R.id.deviceName) as TextView
            deviceNameViewer.text = str
            val checkBox = view.findViewById<View>(R.id.selectDevice) as ImageView

            if (model.isSelected) {
                checkBox.setImageResource(R.drawable.ic_check_on)
                deviceNameViewer.setTextColor(Color.WHITE)
            } else {
                checkBox.setImageResource(R.drawable.ic_check_off)
                deviceNameViewer.setTextColor(Color.parseColor("#99ffffff"))
            }

            if (!TextUtils.isEmpty(str) && (str == getString(R.string.msg_none_found) || str == getString(R.string.msg_none_paired))) {
                checkBox.visibility = View.GONE
            }

            view.setOnClickListener {
//                for (deviceModel in pairedDeviceListToShow) {
//                    deviceModel.isSelected = deviceModel == model
//                }

                for (deviceModel in newDeviceListToShow) {
                    deviceModel.isSelected = deviceModel == model
                }

                newDeviceListAdapter.notifyDataSetChanged()
                selectedDevice = model
            }
            return view
        }
    }

    private fun setListViewHeightBasedOnChildren(listView: ListView) {
        val listAdapter = listView.adapter ?: return

        val desiredWidth = View.MeasureSpec.makeMeasureSpec(listView.width, View.MeasureSpec.UNSPECIFIED)
        var totalHeight = 0
        var view: View? = null
        for (i in 0 until listAdapter.count) {
            view = listAdapter.getView(i, view, listView)
            if (i == 0)
                view!!.layoutParams = ViewGroup.LayoutParams(desiredWidth, ViewGroup.LayoutParams.WRAP_CONTENT)

            view!!.measure(desiredWidth, View.MeasureSpec.UNSPECIFIED)
            totalHeight += view.measuredHeight
        }
        val params = listView.layoutParams
        params.height = totalHeight + listView.dividerHeight * (listAdapter.count - 1)
        listView.layoutParams = params
    }

    @SuppressLint("HandlerLeak")
    private val mHandler = object : Handler() {

        override fun handleMessage(msg: Message) {
            //JQuery.e("GOT MESSAGE:::: " + msg.what)
            when (msg.what) {
                Devicetransfer.MESSAGE_STATE_CHANGE -> {
                    //JQuery.e("MESSAGE_STATE_CHANGE: " + msg.arg1)
                    when (msg.arg1) {
                        BluetoothService.STATE_CONNECTED -> {
                        }
                        BluetoothService.STATE_CONNECTING -> {
                        }
                        BluetoothService.STATE_LISTEN, BluetoothService.STATE_NONE -> {
                        }
                    }
                }
                Devicetransfer.MESSAGE_WRITE -> {
                }
                Devicetransfer.MESSAGE_READ -> {
                }
                Devicetransfer.MESSAGE_DEVICE_NAME -> {
                    Toast.makeText(
                        applicationContext,
                        "Connected to " + msg.data.getString(Devicetransfer.DEVICE_NAME)!!,
                        Toast.LENGTH_LONG
                    ).show()
                    hideProgressDialog()
                    restartActivity(DashboardActivity::class.java)
                }
                Devicetransfer.MESSAGE_TOAST,

                Devicetransfer.MESSAGE_UNABLE_TO_CONNECT -> {

                    //JQuery.d("UNABLE TO CONNECT")
                    if (BluetoothService.getState() != BluetoothService.STATE_CONNECTED) {
                        BluetoothService.setForceStopped(true)
                        Toast.makeText(applicationContext, msg.data.getString(Devicetransfer.TOAST), Toast.LENGTH_LONG)
                            .show()
                        hideProgressDialog()
                    }
                }

                Devicetransfer.MESSAGE_BLUETOOTH_ERROR -> Toast.makeText(
                    applicationContext,
                    "BLUETOOTH ERROR",
                    Toast.LENGTH_SHORT
                ).show()

                Devicetransfer.MESSAGE_DISTOERROR -> Toast.makeText(
                    applicationContext,
                    "DISTO ERROR",
                    Toast.LENGTH_SHORT
                ).show()

                Devicetransfer.MESSAGE_KEYBOARD -> Toast.makeText(
                    applicationContext,
                    "KEYBOARD ERROR",
                    Toast.LENGTH_SHORT
                ).show()

                Devicetransfer.MESSAGE_RESULT -> {
                }
            }
        }
    }

}
