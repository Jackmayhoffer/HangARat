package com.itikarus.hat.api

import com.google.gson.GsonBuilder
import com.itikarus.hat.model.ResBase
import com.itikarus.hat.model.ResGetValue
import com.itikarus.hat.model.ResSignup
import java.security.cert.CertificateException
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import okhttp3.OkHttpClient
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.FieldMap
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

object ApiClient {

    private var API_MAIN_ROOT = "http://hangarat.com/backend/api/apis/"

    private var apiMainService: ApiInterface? = null

    val apiClient: ApiInterface?
        get() {
            if (apiMainService == null) {

                val client = unsafeOkHttpClient

                val gson = GsonBuilder()
                        .setLenient()
                        .create()
                val retrofit = Retrofit.Builder()
                        .baseUrl(API_MAIN_ROOT)
                        .addConverterFactory(GsonConverterFactory.create(gson))
                        .client(client)
                        .build()
                apiMainService = retrofit.create(ApiInterface::class.java)
            }

            return apiMainService
        }

    private// Create a trust manager that does not validate certificate chains
    // Install the all-trusting trust manager
    // Create an ssl socket factory with our all-trusting manager
    val unsafeOkHttpClient: OkHttpClient
        get() {

            try {
                val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
                    @Throws(CertificateException::class)
                    override fun checkClientTrusted(chain: Array<java.security.cert.X509Certificate>, authType: String) {

                    }

                    @Throws(CertificateException::class)
                    override fun checkServerTrusted(chain: Array<java.security.cert.X509Certificate>, authType: String) {

                    }

                    override fun getAcceptedIssuers(): Array<java.security.cert.X509Certificate> {
                        return arrayOf()
                    }
                })

                val sslContext = SSLContext.getInstance("SSL")
                sslContext.init(null, trustAllCerts, java.security.SecureRandom())
                val sslSocketFactory = sslContext.socketFactory

                val builder = OkHttpClient.Builder()
                builder.readTimeout(60, TimeUnit.SECONDS)
                builder.connectTimeout(30, TimeUnit.SECONDS)
                builder.writeTimeout(30, TimeUnit.SECONDS)
                builder.sslSocketFactory(sslSocketFactory, trustAllCerts[0] as X509TrustManager)
                builder.hostnameVerifier { _, _ -> true }

                return builder.build()
            } catch (e: Exception) {
                throw RuntimeException(e)
            }

        }

    interface ApiInterface {
        @POST("signup")
        @FormUrlEncoded
        fun signup(@FieldMap options: Map<String, String>): Call<ResSignup>

        @POST("signin")
        @FormUrlEncoded
        fun signin(@FieldMap options: Map<String, String>): Call<ResSignup>

        @POST("sendvalue")
        @FormUrlEncoded
        fun sendValue(@FieldMap options: Map<String, String>): Call<ResBase>

        @POST("getvalue")
        @FormUrlEncoded
        fun getValue(@FieldMap options: Map<String, String>): Call<ResGetValue>

        @POST("forgotpw")
        @FormUrlEncoded
        fun forgotPassword(@FieldMap options: Map<String, String>): Call<ResBase>

        @POST("deleteWeights")
        @FormUrlEncoded
        fun clearWeights(@FieldMap options: Map<String, String>): Call<ResBase>

    }
}
