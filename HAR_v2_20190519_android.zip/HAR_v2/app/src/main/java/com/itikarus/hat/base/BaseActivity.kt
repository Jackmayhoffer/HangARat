


package com.itikarus.hat.base

import android.app.Activity
import android.app.Dialog
import android.app.FragmentTransaction
import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.support.design.widget.Snackbar
import android.support.v7.app.AppCompatActivity
import android.text.TextUtils
import android.view.View
import android.view.Window
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.TextView
import com.itikarus.hat.R

open class BaseActivity : AppCompatActivity() {

    protected val TAG = javaClass.simpleName

    private var progressDialog: ProgressDialog? = null

    private var titleViewer: TextView? = null

    var activity: Activity? = null

    fun restartActivity(cls: Class<*>) {
        val intent = Intent(this, cls)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
        startActivity(intent)
        finish()
    }

    fun restartActivity(cls: Class<*>, direct: Int) {
        val intent = Intent(this, cls)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        when (direct) {
            LR -> overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_right)
            RL -> overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_left)
            TB -> overridePendingTransition(R.anim.anim_slide_in_top, R.anim.anim_slide_out_bottom)
            BT -> overridePendingTransition(R.anim.anim_slide_in_bottom, R.anim.anim_slide_out_top)
        }
        finish()
    }

    fun restartActivity(intent: Intent) {
        //intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent)
        finish()
    }

    fun startActivity(cls: Class<*>) {
        val intent = Intent(this, cls)
        startActivity(intent)
    }

    fun checkEditText(edit: EditText?, value: Out<String>): Boolean {
        if (edit == null) return false
        edit.error = null
        val string = edit.text.toString()
        if (TextUtils.isEmpty(string)) {
            edit.error = "This field is required"
            edit.requestFocus()
            return false
        }
        value.set(string)
        return true
    }

    fun checkEmail(edit: EditText, value: Out<String>): Boolean {
        if (!checkEditText(edit, value)) return false
        val string = value.get()
        val res = !TextUtils.isEmpty(string) && android.util.Patterns.EMAIL_ADDRESS.matcher(string).matches()
        if (!res) {
            edit.error = "Invalid email format."
            edit.requestFocus()
            return false
        }
        return true
    }

    fun checkTextView(textView: TextView?, value: Out<String>): Boolean {
        if (textView == null) return false
        textView.error = null
        val string = textView.text.toString()
        if (TextUtils.isEmpty(string)) {
            return false
        }
        value.set(string)
        return true
    }

    fun showKeyboard(view: View) {
        val inputMethodManager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.toggleSoftInputFromWindow(view.applicationWindowToken, InputMethodManager.SHOW_FORCED, 0)
    }

    fun hideKeyboard(view: View?) {
        if (view != null) {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm?.hideSoftInputFromWindow(view.windowToken, 0)
        }
    }


    class Out<T> {
        var s: T? = null

        fun set(value: T) {
            s = value
        }

        fun get(): T? {
            return s
        }
    }

    fun showDialog(dialog: Dialog) {
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.requestFeature(Window.FEATURE_NO_TITLE)
        dialog.show()
    }

    @JvmOverloads
    fun showProgressDialog(message: String = "") {
        if (progressDialog == null) {
            progressDialog = ProgressDialog(this, ProgressDialog.THEME_DEVICE_DEFAULT_LIGHT)
            progressDialog!!.setProgressStyle(ProgressDialog.STYLE_SPINNER)
            //progressDialog!!.setTitle("Wait...")
        }
        progressDialog!!.setMessage(message)
        progressDialog!!.show()
    }

    fun hideProgressDialog() {
        if (progressDialog != null) progressDialog!!.dismiss()
    }

    fun setFragment(fragment: BaseFragment) {
        try {
            transitionFragment(fragment)

        } catch (e: IllegalStateException) {
            e.printStackTrace()
        }

    }

    private fun transitionFragment(fragment: BaseFragment) {

        val fragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.addToBackStack("Transaction1")
        //fragmentTransaction.replace(R.id.fragment_container_rl, fragment, fragment.javaClass.simpleName)
        fragmentTransaction.setTransitionStyle(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
        fragmentTransaction.commit()

    }

    protected open fun serviceStarted() {

    }

    companion object {

        @JvmStatic
        fun Crouton(activity: Activity, msg: String, result: Boolean) {

            val snackbar = Snackbar.make(activity.findViewById(android.R.id.content), msg, Snackbar.LENGTH_LONG)
            val snackBarView = snackbar.view
            val tv = snackBarView.findViewById<TextView>(android.support.design.R.id.snackbar_text)
            tv.setTextColor(Color.BLACK)
            tv.textSize = 17f
            if (result) {
                snackBarView.setBackgroundColor(Color.WHITE)
            } else {
                snackBarView.setBackgroundColor(Color.parseColor("#f8d915"))
            }
            snackbar.show()
        }

        val RL = 0
        val LR = 1
        val TB = 2
        val BT = 3
        val NT = 4
    }
}
