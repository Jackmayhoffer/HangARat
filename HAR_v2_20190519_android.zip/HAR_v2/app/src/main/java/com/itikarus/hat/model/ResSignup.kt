package com.itikarus.hat.model

import com.google.gson.annotations.SerializedName

class ResSignup : ResBase(){
    @SerializedName("UserData")
    var userModel = UserModel()
}