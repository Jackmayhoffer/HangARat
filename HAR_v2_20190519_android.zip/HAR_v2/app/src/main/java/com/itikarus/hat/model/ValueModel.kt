package com.itikarus.hat.model

import com.google.gson.annotations.SerializedName

class ValueModel : Comparable<ValueModel>{

    override fun compareTo(other: ValueModel): Int {
        return other.value.toInt() - this.value.toInt()
    }

    @SerializedName("UserName")
    var userName = ""
    @SerializedName("Value")
    var value = 0f
    @SerializedName("Created")
    var createdDt = ""

}