package com.itikarus.hat.model

import com.google.gson.annotations.SerializedName

class UserModel {
    @SerializedName("id")
    var userId = ""
    @SerializedName("userName")
    var userName = ""
    @SerializedName("email")
    var email = ""
}