package com.itikarus.hat.model

import com.google.gson.annotations.SerializedName

class ResGetValue : ResBase(){
    @SerializedName("values")
    var values = ArrayList<ValueModel>()
}