package com.itikarus.hat

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.support.v4.app.ActionBarDrawerToggle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import com.itikarus.hangaratlib.BluetoothService
import com.itikarus.hat.base.BaseActivity
import com.itikarus.hat.global.GlobalStorage
import com.itikarus.hat.library.utils.DialogUtils
import com.itikarus.hat.model.SigninInfo
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.layout_drawer.*
import kotlinx.android.synthetic.main.layout_header.*

abstract class MainActivity : BaseActivity() {

    private lateinit var mHandler: Handler

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mHandler = Handler(mainLooper)
        val inflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val mainView = inflater.inflate(getPageLayoutId(), null)
        rl_mainPageContainer.addView(mainView)
        drawerMenuSetting()
        showConnectionStatusViewer(BluetoothService.getState() == BluetoothService.STATE_CONNECTED)
        showUserInfo()
        tv_titleViewer.text = getScreenTitle()
    }

    fun isConnectedDevice() : Boolean{
        return BluetoothService.getState() == BluetoothService.STATE_CONNECTED
    }

    fun showConnectionStatusViewer(isConnected : Boolean){
        if(isConnected){
            //iv_connectionStatusViewer.setBackgroundResource(R.drawable.outline_blue)
        }else{
            //iv_connectionStatusViewer.setBackgroundResource(R.drawable.outline_red)
        }
    }

    @SuppressLint("SetTextI18n")
    fun showUserInfo(){
        if(SigninInfo.build(this).hasAuth()){
            tv_usernameViewer.text = SigninInfo.build(this).username
            tv_usernameViewer.setTextColor(Color.YELLOW)
        }else{
            tv_usernameViewer.text = "You're not registered yet"
            tv_usernameViewer.setTextColor(Color.RED)
        }
    }

    private fun drawerMenuSetting() {
        if(SigninInfo.build(this).hasAuth()){
            tv_linkLogin.text = "Logout"
        }
        arrayOf(tv_linkDashboard, tv_linkLogs, tv_linkCompetition, tv_linkSettings,
                tv_linkFaq, tv_linkFeedback, tv_linkLogin, tv_linkTermsPolicy).forEach {view->
            view.setOnClickListener {
                drawer_layout.closeDrawers()

                when(it.id){
                    R.id.tv_linkDashboard -> {
                        if (this is DashboardActivity) return@setOnClickListener

                        mHandler.postDelayed({ restartActivity(DashboardActivity::class.java) }, 500)
                    }
                    R.id.tv_linkLogs -> {

                        if (this is LogsActivity) return@setOnClickListener

                        mHandler.postDelayed({ checkAuth{restartActivity(LogsActivity::class.java)}  }, 500)
                    }
                    R.id.tv_linkCompetition -> {
                        if (this is CompetitionActivity) return@setOnClickListener
                        mHandler.postDelayed({ checkAuth{restartActivity(CompetitionActivity::class.java)}}, 500)
                    }
                    R.id.tv_linkSettings -> {
                        if (this is SettingsActivity) return@setOnClickListener
                        mHandler.postDelayed({ restartActivity(SettingsActivity::class.java) }, 500)
                    }
                    R.id.tv_linkFaq -> {
                        if (this is FAQActivity) return@setOnClickListener
                        mHandler.postDelayed({ restartActivity(FAQActivity::class.java) }, 500)
                    }
                    R.id.tv_linkFeedback -> {
                        if (this is FeedbackActivity) return@setOnClickListener

                        mHandler.postDelayed({ restartActivity(FeedbackActivity::class.java) }, 500)
                    }
                    R.id.tv_linkLogin -> {

                        if (this is SigninActivity) return@setOnClickListener
                        if(SigninInfo.build(this).hasAuth()){
                            SigninInfo.build(this).clear()
                        }
                        mHandler.postDelayed({ restartActivity(SigninActivity::class.java) }, 500)
                    }
                    R.id.tv_linkTermsPolicy -> {
                        if (this is TermsAndPolicyActivity) return@setOnClickListener
                        mHandler.postDelayed({ restartActivity(TermsAndPolicyActivity::class.java) }, 500)
                    }
                }
            }
        }

        val mDrawerToggle = object : ActionBarDrawerToggle(this, drawer_layout, R.drawable.ic_menu, R.string.app_name, R.string.app_name) {
            override fun onDrawerClosed(view: View) {
                supportInvalidateOptionsMenu()
            }

            override fun onDrawerOpened(drawerView: View) {
                supportInvalidateOptionsMenu()
            }

            override fun onDrawerSlide(drawerView: View, slideOffset: Float) {
                super.onDrawerSlide(drawerView, slideOffset)
                rl_mainView.translationX = slideOffset * drawerView.width
                drawer_layout.bringChildToFront(drawerView)
                drawer_layout.requestLayout()
            }
        }

        drawer_layout.setDrawerListener(mDrawerToggle)
        iv_btnMenu.setOnClickListener { drawer_layout.openDrawer(Gravity.LEFT) }
    }

    protected abstract fun getPageLayoutId(): Int

    protected abstract fun getScreenTitle() : String

    private val SIGNINREQUEST = 1002
    fun checkAuth(action : (() -> Unit)?) : Boolean{
        return if(SigninInfo.build(this).hasAuth())
        {
            action?.invoke()
            true
        }
        else{
            DialogUtils.showOkayDialog(this, getString(R.string.app_name), "Please sign in to post your results"){
                GlobalStorage.actionAfterSignin = action
                val authIntent = Intent(this@MainActivity, SigninActivity::class.java)
                startActivityForResult(authIntent, SIGNINREQUEST)
            }
            false
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if(requestCode == SIGNINREQUEST && resultCode == Activity.RESULT_OK){
            GlobalStorage.actionAfterSignin?.invoke()
        }
    }

    var doubleBackToExitPressedOnce = false
    override fun onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            BluetoothService.disableBluetooth()
            finish()
            return
        }
        this.doubleBackToExitPressedOnce = true
        Crouton(this, "Press back again to exit", true)
        Handler().postDelayed({ doubleBackToExitPressedOnce = false }, 2000)
    }
}
