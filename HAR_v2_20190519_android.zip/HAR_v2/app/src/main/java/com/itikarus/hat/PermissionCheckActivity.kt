package com.itikarus.hat

import android.content.pm.PackageManager
import android.os.Build
import android.support.v4.app.ActivityCompat
import com.itikarus.hat.base.BaseActivity
import com.itikarus.hat.library.utils.DialogUtils
import java.util.HashMap

abstract class PermissionCheckActivity : BaseActivity() {

    private val PERMISSION_REQUEST_CODE = 1001

    private var actionAfterPermissionCheck : (() -> Unit)? = null

    protected fun permissionCheck(action : (() -> Unit)? = null): Boolean {
        actionAfterPermissionCheck = action
        return if (Build.VERSION.SDK_INT >= 23) {
            if (!isGuaranteedPermissions()) {
                ActivityCompat.requestPermissions(this, requiredPermissions(), PERMISSION_REQUEST_CODE)
                false
            } else {
                actionAfterPermissionCheck?.invoke()
                true
            }
        } else {
            actionAfterPermissionCheck?.invoke()
            true
        }
    }

    private fun isGuaranteedPermissions() : Boolean{
        requiredPermissions().forEach {
            if(Build.VERSION.SDK_INT >= 23){
                if(checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED) return false
            }
        }
        return true
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        when (requestCode) {
            PERMISSION_REQUEST_CODE -> {
                val perms = HashMap<String, Int>()
                requiredPermissions().forEach {
                    perms[it] = PackageManager.PERMISSION_GRANTED
                }

                for (i in permissions.indices) {
                    perms[permissions[i]] = grantResults[i]
                }

                if (checkPermissionsResult(perms)) {
                    // All Permissions Granted
                    actionAfterPermissionCheck?.invoke()
                } else {
                    // Permission Denied
                    DialogUtils.showOkayDialog(this, getString(R.string.app_name), getString(R.string.permission_denied)) {

                    }
                }
            }
            else -> super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        }
    }

    private fun checkPermissionsResult(perms : HashMap<String, Int>) : Boolean{
        requiredPermissions().forEach {
            if(perms[it] != PackageManager.PERMISSION_GRANTED) return false
        }
        return true
    }

    abstract fun requiredPermissions() : Array<String>
}