/**
 * ©Copyright EXZA ® 2018. All rights reserved.
 */

package com.itikarus.hat.base

import android.app.Activity
import android.app.Fragment
import android.graphics.Color
import android.support.design.widget.Snackbar
import android.support.v7.widget.DefaultItemAnimator
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.view.View
import android.widget.EditText
import android.widget.TextView


open class BaseFragment : Fragment() {

    var mRootView: View? = null

    fun checkEditText(edit: EditText?, value: Out<String>): Boolean {
        if (edit == null) return false
        edit.error = null
        val string = edit.text.toString()
        if (TextUtils.isEmpty(string)) {
            edit.error = "Type the name"
            edit.requestFocus()
            return false
        }
        value.set(string)
        return true
    }

    class Out<T> {
        var s: T? = null

        fun set(value: T) {
            s = value
        }

        fun get(): T? {
            return s
        }
    }

    fun setmRootView(view: View) {

        mRootView = view
    }

    fun Crouton(act: Activity, msg: String, result: Boolean) {

        val snackbar = Snackbar.make(act.findViewById(android.R.id.content), msg, Snackbar.LENGTH_LONG)
        val snackBarView = snackbar.view
        val tv = snackBarView.findViewById<View>(android.support.design.R.id.snackbar_text) as TextView
        tv.setTextColor(Color.WHITE)
        tv.textSize = 17f
        tv.textAlignment = View.TEXT_ALIGNMENT_CENTER
        if (result) {
            snackBarView.setBackgroundColor(Color.parseColor("#868689"))
        } else {
            snackBarView.setBackgroundColor(Color.RED)
        }
        snackbar.show()
    }

    fun createSimpleRecyclerView(act: Activity, resId: Int): RecyclerView {
        val mLayoutManager = LinearLayoutManager(act)
        val mRecyclerView: RecyclerView = mRootView!!.findViewById<View>(resId) as RecyclerView
        mRecyclerView.layoutManager = mLayoutManager
        mRecyclerView.itemAnimator = DefaultItemAnimator()
        return mRecyclerView
    }
}
