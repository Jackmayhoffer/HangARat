package com.itikarus.hat.model

import android.content.Context
import com.itikarus.hat.library.utils.TinyDB

class SavedPostValue(context: Context) {

    var savedValue = "0.0"
        set(value) {
            field = value
            update()
        }

    fun hasValidValue() : Boolean{
        return savedValue.isNotEmpty() && savedValue.toFloat() > 0
    }

    init {
        mDB = TinyDB(context)
    }

    fun update() {
        mDB!!.putObject(LOGIN_DATA, this)
    }

    fun clear() {
        savedValue = "0.000"
        update()
    }


    companion object {

        private val LOGIN_DATA = "saved_post_value"

        private var mDB: TinyDB? = null

        fun build(context: Context): SavedPostValue {
            mDB = TinyDB(context)
            try {
                return mDB!!.getObject(LOGIN_DATA, SavedPostValue::class.java) as SavedPostValue
            } catch (e: NullPointerException) {
                return SavedPostValue(context)
            }

        }
    }
}
