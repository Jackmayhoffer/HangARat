#!/bin/sh

swiftgen strings --templatePath "templates/strings.stencil" --param enumName=L10n --output "../Gluxus/Definitions/Strings.swift" ../Gluxus/Localizable.strings
