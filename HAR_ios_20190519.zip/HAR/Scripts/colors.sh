#!/bin/sh

swiftgen colors --templatePath "templates/colors.stencil" --param enumName=MTColor --output "../Gluxus/Definitions/Colors.swift" ../Gluxus/Definitions/colors.txt
