#!/bin/sh

swiftgen storyboards --templatePath "templates/storyboards.stencil" --param sceneEnumName=HDRStoryboard --param segueEnumName=HDRStoryboardSegue --output "../HDR/Definitions/Storyboard.swift" ../HDR/
