#!/bin/sh

swiftgen xcassets --templatePath "templates/xcassets.stencil" --param enumName=GLAssets --output "../Gluxus/Definitions/XCAssets.swift" ../Gluxus/Assets.xcassets
