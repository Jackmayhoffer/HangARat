//
//  Definitions.swift
//  TalkingStatues
//
//  Created by Alex on 6/6/2018.
//  Copyright © 2018 alex. All rights reserved.
//

import Foundation
