
// Generated using SwiftGen, by O.Halligon — https://github.com/SwiftGen/SwiftGen

#if os(OSX)
  import AppKit.NSColor
  internal typealias Color = NSColor
#elseif os(iOS) || os(tvOS) || os(watchOS)
  import UIKit.UIColor
  internal typealias Color = UIColor
#endif

// swiftlint:disable superfluous_disable_command
// swiftlint:disable file_length

// swiftlint:disable operator_usage_whitespace
internal extension Color {
  convenience init(rgbaValue: UInt32) {
    let red   = CGFloat((rgbaValue >> 24) & 0xff) / 255.0
    let green = CGFloat((rgbaValue >> 16) & 0xff) / 255.0
    let blue  = CGFloat((rgbaValue >>  8) & 0xff) / 255.0
    let alpha = CGFloat((rgbaValue      ) & 0xff) / 255.0

    self.init(red: red, green: green, blue: blue, alpha: alpha)
  }
}
// swiftlint:enable operator_usage_whitespace

// swiftlint:disable identifier_name line_length type_body_length
internal struct SPColor {
  internal let rgbaValue: UInt32
  internal var color: Color { return Color(named: self) }

  /// <span style="display:block;width:3em;height:2em;border:1px solid black;background:#2c2d2c"></span>
  /// Alpha: 100% <br/> (0x2c2d2cff)
  internal static let darkBlack = SPColor(rgbaValue: 0x2c2d2cff)
  /// <span style="display:block;width:3em;height:2em;border:1px solid black;background:#3f3f3f"></span>
  /// Alpha: 100% <br/> (0x3f3f3fff)
  internal static let lightBlack = SPColor(rgbaValue: 0x3f3f3fff)
  /// <span style="display:block;width:3em;height:2em;border:1px solid black;background:#525252"></span>
  /// Alpha: 100% <br/> (0x525252ff)
  internal static let lightBlackButton = SPColor(rgbaValue: 0x525252ff)
  /// <span style="display:block;width:3em;height:2em;border:1px solid black;background:#404040"></span>
  /// Alpha: 100% <br/> (0x404040ff)
  internal static let lightBlackButtonShadow = SPColor(rgbaValue: 0x404040ff)
  /// <span style="display:block;width:3em;height:2em;border:1px solid black;background:#69b4eb"></span>
  /// Alpha: 100% <br/> (0x69b4ebff)
  internal static let lightBlue = SPColor(rgbaValue: 0x69b4ebff)
  /// <span style="display:block;width:3em;height:2em;border:1px solid black;background:#f6f6f6"></span>
  /// Alpha: 100% <br/> (0xf6f6f6ff)
  internal static let lightGrayBG = SPColor(rgbaValue: 0xf6f6f6ff)
  /// <span style="display:block;width:3em;height:2em;border:1px solid black;background:#26c876"></span>
  /// Alpha: 100% <br/> (0x26c876ff)
  internal static let lightGreen = SPColor(rgbaValue: 0x26c876ff)
  /// <span style="display:block;width:3em;height:2em;border:1px solid black;background:#3b90e7"></span>
  /// Alpha: 100% <br/> (0x3b90e7ff)
  internal static let lightGreenButton = SPColor(rgbaValue: 0x3b90e7ff)
  /// <span style="display:block;width:3em;height:2em;border:1px solid black;background:#3179c3"></span>
  /// Alpha: 100% <br/> (0x3179c3ff)
  internal static let lightGreenButtonShadow = SPColor(rgbaValue: 0x3179c3ff)
  /// <span style="display:block;width:3em;height:2em;border:1px solid black;background:#f14848"></span>
  /// Alpha: 100% <br/> (0xf14848ff)
  internal static let lightRed = SPColor(rgbaValue: 0xf14848ff)
  /// <span style="display:block;width:3em;height:2em;border:1px solid black;background:#f6464b"></span>
  /// Alpha: 100% <br/> (0xf6464bff)
  internal static let lightRedButton = SPColor(rgbaValue: 0xf6464bff)
  /// <span style="display:block;width:3em;height:2em;border:1px solid black;background:#da393e"></span>
  /// Alpha: 100% <br/> (0xda393eff)
  internal static let lightRedButtonShadow = SPColor(rgbaValue: 0xda393eff)
  /// <span style="display:block;width:3em;height:2em;border:1px solid black;background:#383737"></span>
  /// Alpha: 100% <br/> (0x383737ff)
  internal static let navigationBarTitle = SPColor(rgbaValue: 0x383737ff)
}
// swiftlint:enable identifier_name line_length type_body_length

internal extension Color {
  convenience init(named color: SPColor) {
    self.init(rgbaValue: color.rgbaValue)
  }
}
