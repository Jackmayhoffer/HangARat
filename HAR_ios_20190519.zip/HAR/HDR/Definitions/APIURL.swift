//
//  APIURL.swift
//  TalkingStatues
//
//  Created by Alex on 5/6/2018.
//  Copyright © 2018 alex. All rights reserved.
//

import Foundation
import Alamofire

struct APIURL {
    let path:String
    
    static let endPoint = "http://hangarat.com/backend/api/apis"
    
    // Add log api
    static let log_error: APIURL = "/log_error.php"
    
    // Define all apis here...
    static let signin: APIURL = "/signin"
    static let signup: APIURL = "/signup"
    static let sendvalue: APIURL = "/sendvalue"
    static let getvalue: APIURL = "/getvalue"
    static let forgotPassword: APIURL = "/forgotpw"
    static let clearWeights: APIURL = "deleteWeights"
}

// MARK: - Extend APIURL to conform URLConvertible
extension APIURL:URLConvertible{
    func asURL() throws -> URL {
        #if IS_DEBUG
        return URL(string: APIURL.endPoint + path + "?XDEBUG_SESSION_START=PHPSTORM")!
        #endif
        return URL(string: APIURL.endPoint + path)!
    }
}

extension APIURL: ExpressibleByStringLiteral {
    init(stringLiteral value: String) {
        path = value
    }
    
    init(unicodeScalarLiteral value: String) {
        path = value
    }
    
    init(extendedGraphemeClusterLiteral value: String) {
        path = value
    }
}
