//
//  APIError.swift
//  TalkingStatues
//
//  Created by Alex on 5/6/2018.
//  Copyright © 2018 alex. All rights reserved.
//

import Foundation

let kAPIErrorSuccess = 0

enum APIError {
    case unknown(String?)
}

extension APIError: Error { }

extension APIError: LocalizedError {
    var errorDescription: String? {
        switch self {
        case .unknown(let msg):
            return msg
        }
    }
    
    init?(response: APIResponse) {
        switch response.code {
        case kAPIErrorSuccess:
            return nil
        default:
            self = .unknown(response.message)
        }
    }
}

extension Error {
    func errorMessage(message: String) -> String {
        var msg = self.localizedDescription
        if msg == "" {
            msg = message
        }
        return msg
    }
}
