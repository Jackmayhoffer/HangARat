//
//  SplashViewController.swift
//  HDR
//
//  Created by Alex Chang on 4/27/19.
//  Copyright © 2019 alex. All rights reserved.
//

import UIKit

class SplashViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            self.gotoNextVC()
        }
    }
    
    func gotoNextVC() {
        let vc = HDRStoryboard.ScanScene.scanViewController.instantiate()
        let navVC = UINavigationController(rootViewController: vc)
        navVC.isNavigationBarHidden = true
        
        UIApplication.shared.keyWindow?.rootViewController = navVC
    }
}
