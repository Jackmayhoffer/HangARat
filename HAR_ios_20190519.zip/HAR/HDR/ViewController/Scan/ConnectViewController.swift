//
//  ConnectViewController.swift
//  HDR
//
//  Created by Alex Chang on 4/4/19.
//  Copyright © 2019 alex. All rights reserved.
//

import UIKit
import CoreBluetooth

class ConnectViewController: UIViewController {

    @IBOutlet weak var foundTableView: UITableView!
    @IBOutlet weak var pairButton: UIButton!
    
    var hud: MBProgressHUD? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        foundTableView.register(DeviceCell.self)
        
        foundTableView.dataSource = self
        foundTableView.delegate = self
        
        pairButton.isEnabled = false
        pairButton.alpha = 0.5
        
        AppContext.shared.bleManager.disconnectCurrentConnection()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        scanDevices()
    }
    
    @IBAction func backButtonTapped(_ sender: Any) {
        _ = popViewController()
    }
    
    @IBAction func scanButtonTapped(_ sender: Any) {
        scanDevices()
    }
    
    @IBAction func paireButtonTapped(_ sender: Any) {
        guard let indexPath = foundTableView.indexPathForSelectedRow else { return }
        
        hud  = showActivityHUDTopMost(message: "Connecting...")
        AppContext.shared.bleManager.addDelegate(self)
        AppContext.shared.bleManager.connectPeripheral(index: indexPath.row)
    }
    
    func scanDevices() {
        let hud = showActivityHUDTopMost()
        
        AppContext.shared.bleManager.stopScanning()
        AppContext.shared.bleManager.startScanning()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 10.0) {
            AppContext.shared.bleManager.stopScanning()
            hud.hide(animated: true)
            self.foundTableView.reloadData()
        }
    }
}

extension ConnectViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return AppContext.shared.bleManager.searchedPeripherals.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(for: indexPath) as DeviceCell
        let peripheral = AppContext.shared.bleManager.searchedPeripherals[indexPath.row]
        
        cell.deviceNameLabel.text = peripheral.name ?? "Unknown Device"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        pairButton.isEnabled = true
        pairButton.alpha = 1
    }
}

extension ConnectViewController: BLEManagerDelegate {
    func bleManagerDidConnect(_ manager: BLEManagable) {
        hud?.hide(animated: true)
        hud = nil
        let vc = HDRStoryboard.MainScene.mainViewController.instantiate()
        UIApplication.shared.keyWindow?.rootViewController = vc
    }
    
    func bleManagerFailedConnect(_ manager: BLEManagable) {
        hud?.hide(animated: true)
        hud = nil
        
        alertWithOK(message: "Failed to connect to the device")
    }
}
