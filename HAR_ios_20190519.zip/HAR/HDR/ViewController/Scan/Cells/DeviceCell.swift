//
//  DeviceCell.swift
//  HDR
//
//  Created by Alex Chang on 4/4/19.
//  Copyright © 2019 alex. All rights reserved.
//

import UIKit

class DeviceCell: UITableViewCell {

    @IBOutlet weak var deviceNameLabel: UILabel!
    @IBOutlet weak var checkButton: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        if isSelected {
            deviceNameLabel.alpha = 1
            checkButton.alpha = 1
            checkButton.setImage(UIImage(named: "ic_checkbox_on"), for: .normal)
        } else {
            deviceNameLabel.alpha = 0.6
            checkButton.alpha = 0.6
            checkButton.setImage(UIImage(named: "ic_checkbox_off"), for: .normal)
        }
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
        
        if selected {
            deviceNameLabel.alpha = 1
            checkButton.alpha = 1
            checkButton.setImage(UIImage(named: "ic_checkbox_on"), for: .normal)
        } else {
            deviceNameLabel.alpha = 0.6
            checkButton.alpha = 0.6
            checkButton.setImage(UIImage(named: "ic_checkbox_off"), for: .normal)
        }
    }
    
}

extension DeviceCell: NibLoadableView { }
