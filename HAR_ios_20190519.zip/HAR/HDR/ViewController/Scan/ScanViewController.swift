//
//  ScanViewController.swift
//  HDR
//
//  Created by Alex Chang on 4/3/19.
//  Copyright © 2019 alex. All rights reserved.
//

import UIKit

class ScanViewController: UIViewController {

    @IBOutlet weak var progressImageView: UIImageView!
    @IBOutlet weak var turnImageView: UIImageView!
    
    var timer: Timer?
    
    var duration = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func scanButtonTapped(_ sender: Any) {
        guard timer == nil else { return }
        
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(progress), userInfo: nil, repeats: true)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            self.turnImageView.image = UIImage(named: "ic_progress")
        }
    }
    
    @IBAction func connectLaterButtonTapped(_ sender: Any) {
        let vc = HDRStoryboard.MainScene.mainViewController.instantiate()
        UIApplication.shared.keyWindow?.rootViewController = vc
    }
    
    @objc func progress() {
        UIView.animate(withDuration: 1.5) {
            self.progressImageView.transform = self.progressImageView.transform.rotated(by: .pi)
            self.turnImageView.transform = self.turnImageView.transform.rotated(by: .pi * 0.75)
        }
        
        duration += 1
        
        if duration > 5 {
            timer?.invalidate()
            timer = nil
            gotoConnectScreen()
        }
    }
    
    func gotoConnectScreen() {
        let vc = HDRStoryboard.ScanScene.connectViewController.instantiate()
        show(vc, sender: nil)
    }
}
