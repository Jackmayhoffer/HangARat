//
//  SignupViewController.swift
//  HDR
//
//  Created by Alex Chang on 4/4/19.
//  Copyright © 2019 alex. All rights reserved.
//

import UIKit

class SignupViewController: UIViewController {

    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var confirmPasswordTextField: UITextField!
    @IBOutlet weak var eyeButton: UIButton!
    
    var isPasswordShow = false {
        didSet {
            if isPasswordShow {
                eyeButton.setImage(UIImage(named: "ic_eye_hidden"), for: .normal)
            } else {
                eyeButton.setImage(UIImage(named: "ic_eye_show"), for: .normal)
            }
            
            passwordTextField.isSecureTextEntry = !isPasswordShow
            confirmPasswordTextField.isSecureTextEntry = !isPasswordShow
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func backButtonTapped(_ sender: Any) {
        _ = popViewController()
    }
    
    @IBAction func signupButtonTapped(_ sender: Any) {
        let hud = showActivityHUD(message: "Registering...")
        
        let userName = userNameTextField.text ?? ""
        let email = emailTextField.text ?? ""
        let password = passwordTextField.text ?? ""
        let confirmPassword = confirmPasswordTextField.text ?? ""
        
        if userName == "" {
            alertWithOK(message: "Please input User Name")
            return
        }
        
        if email == "" {
            alertWithOK(message: "Please input Email")
            return
        }
        
        if !email.isValidEmail {
            alertWithOK(message: "Please input valid Email")
            return
        }
        
        if password == "" {
            alertWithOK(message: "Please input Password")
            return
        }
        
        if password != confirmPassword {
            alertWithOK(message: "Password is not matched.")
            return
        }
        
        APIManager.default.signup(userName: userName, email: email, password: password).subscribe { [weak self] evt in
            hud.hide(animated: true)
            
            switch evt {
            case .next(let json):
                let userData = json["UserData"]
                AppContext.shared.accessToken = json["AccessToken"].stringValue
                AppContext.shared.userCredentials.userName = userData["userName"].stringValue
                AppContext.shared.userCredentials.email = userData["email"].stringValue
                AppContext.shared.userCredentials.save()
                
                _ = self?.navigationController?.popToRootViewController(animated: true)
            case .error(let error):
                self?.alertWithOK(message: error.errorMessage(message: "Failed to Login"))
            default:
                break
            }
        }.disposed(by: rx_disposeBag)
    }
    
    @IBAction func signinButtonTapped(_ sender: Any) {
        _ = popViewController()
    }
    
    @IBAction func eyeButtonTapped(_ sender: Any) {
        isPasswordShow = !isPasswordShow
    }
}
