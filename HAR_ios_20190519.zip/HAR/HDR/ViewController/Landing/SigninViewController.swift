//
//  SigninViewController.swift
//  HDR
//
//  Created by Alex Chang on 4/4/19.
//  Copyright © 2019 alex. All rights reserved.
//

import UIKit

class SigninViewController: UIViewController {

    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var eyeButton: UIButton!
    
    var isPasswordShow = false {
        didSet {
            if isPasswordShow {
                eyeButton.setImage(UIImage(named: "ic_eye_hidden"), for: .normal)
            } else {
                eyeButton.setImage(UIImage(named: "ic_eye_show"), for: .normal)
            }
            
            passwordTextField.isSecureTextEntry = !isPasswordShow
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func backButtonTapped(_ sender: Any) {
        _ = popViewController()
    }
    
    @IBAction func eyeButtonTapped(_ sender: Any) {
        isPasswordShow = !isPasswordShow
    }
    
    @IBAction func signinButtonTapped(_ sender: Any) {
        let hud = showActivityHUD(message: "Loggin In...")
        
        let userName = userNameTextField.text ?? ""
        let password = passwordTextField.text ?? ""
        
        if userName == "" {
            alertWithOK(message: "Please input User Name")
            return
        }
        
        if password == "" {
            alertWithOK(message: "Please input Password")
            return
        }
        
        APIManager.default.signin(userName: userName, password: password).subscribe { [weak self] evt in
            hud.hide(animated: true)
            
            switch evt {
            case .next(let json):
                let userData = json["UserData"]
                AppContext.shared.accessToken = json["AccessToken"].stringValue
                AppContext.shared.userCredentials.userName = userData["userName"].stringValue
                AppContext.shared.userCredentials.email = userData["email"].stringValue
                AppContext.shared.userCredentials.save()
                
                _ = self?.popViewController()
            case .error(let error):
                self?.alertWithOK(message: error.errorMessage(message: "Failed to Login"))
            default:
                break
            }
        }.disposed(by: rx_disposeBag)
    }
    
    @IBAction func signupButtonTapped(_ sender: Any) {
        let vc = HDRStoryboard.LandingScene.signupViewController.instantiate()
        show(vc, sender: nil)
    }
    
    @IBAction func forgotButtonTapped(_ sender: Any) {
        let vc = HDRStoryboard.LandingScene.forgotPasswordViewController.instantiate()
        show(vc, sender: nil)
    }
}
