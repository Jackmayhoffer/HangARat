//
//  ForgotPasswordViewController.swift
//  HDR
//
//  Created by Alex Chang on 4/4/19.
//  Copyright © 2019 alex. All rights reserved.
//

import UIKit

class ForgotPasswordViewController: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func backButtonTapped(_ sender: Any) {
        _ = popViewController()
    }
    
    @IBAction func sendButtonTapped(_ sender: Any) {
        let hud = showActivityHUD(message: "Sending Password...")
        
        let email = emailTextField.text ?? ""
        
        if email == "" {
            alertWithOK(message: "Please input Email")
            return
        }
        
        if !email.isValidEmail {
            alertWithOK(message: "Please input valid Email")
            return
        }
        
        APIManager.default.forgotPassword(email: email).subscribe { [weak self] evt in
            hud.hide(animated: true)
            
            switch evt {
            case .next(let json):
                self?.alertWithOK(message: "Sent password to your email. Please check email.")
            case .error(let error):
                self?.alertWithOK(message: error.errorMessage(message: "Failed to Login"))
            default:
                break
            }
        }.disposed(by: rx_disposeBag)
    }
}
