//
//  MainViewController.swift
//  HDR
//
//  Created by Alex Chang on 4/4/19.
//  Copyright © 2019 alex. All rights reserved.
//

import UIKit

class MainViewController: SlideMenuController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let contentVC = HDRStoryboard.MainScene.dashboardViewController.instantiate()
        let sideMenuVC = HDRStoryboard.MainScene.sideMenuViewController.instantiate()
        
        let contentNavVC = UINavigationController(rootViewController: contentVC)
        contentNavVC.isNavigationBarHidden = true
        
        self.mainViewController = contentNavVC
        self.leftViewController = sideMenuVC
    }
    
    func menuItemSelected(menu: MenuItem) {
        closeLeft()
        
        let navVC = mainViewController as! UINavigationController
        
        switch menu {
        case .dashboard:
            break
        case .logs:
            if checkSignIn() {
                let vc = HDRStoryboard.MainScene.logsViewController.instantiate()
                navVC.pushViewController(vc, animated: true)
            }
        case .competition:
            if checkSignIn() {
                let vc = HDRStoryboard.MainScene.competitionViewController.instantiate()
                navVC.pushViewController(vc, animated: true)
            }
        case .settings:
            break
        case .login:
            let vc = HDRStoryboard.LandingScene.signinViewController.instantiate()
            navVC.pushViewController(vc, animated: true)
        case .logout:
            AppContext.shared.userCredentials.delete()
        case .termsAndPolicy:
            break
        }
    }

    func checkSignIn() -> Bool {
        guard AppContext.shared.accessToken == "" else { return true }
        
        rx.alert(title: nil, message: "Please sign in to post your results", cancelTitle: nil, destructiveTitle: nil, otherTitles: ["YES", "NO"]).subscribe(onNext: { (style, index) in
            if style == .default, index == 0 {
                self.menuItemSelected(menu: .login)
            }
        }).disposed(by: rx_disposeBag)
        
        return false
    }
}
