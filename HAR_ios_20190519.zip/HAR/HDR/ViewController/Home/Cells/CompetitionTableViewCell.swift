//
//  CompetitionTableViewCell.swift
//  HDR
//
//  Created by Alex Chang on 4/6/19.
//  Copyright © 2019 alex. All rights reserved.
//

import UIKit

class CompetitionTableViewCell: UITableViewCell {

    @IBOutlet weak var noLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var valueLabel: UILabel!
    @IBOutlet weak var usernameLabel: UILabel!
    
    var valueModel: ValueModel! {
        didSet {
            dateLabel.text = valueModel.createdAt
            valueLabel.text = "\(valueModel.recordValue)"
            usernameLabel.text = valueModel.userName
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }

}

extension CompetitionTableViewCell: NibLoadableView { }
