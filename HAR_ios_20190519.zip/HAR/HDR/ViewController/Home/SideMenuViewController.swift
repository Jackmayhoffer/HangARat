//
//  SideMenuViewController.swift
//  HDR
//
//  Created by Alex Chang on 4/4/19.
//  Copyright © 2019 alex. All rights reserved.
//

import UIKit

enum MenuItem: String {
    case dashboard = "HangARat"
    case logs = "Personal Stats"
    case competition = "Competition"
    case settings = "Settings"
    case login = "Login"
    case logout = "Logout"
    case termsAndPolicy = "Terms of Service"
    
    static var all: [MenuItem] = [.dashboard, .logs, .competition, .settings, .login, .termsAndPolicy]
}

class SideMenuViewController: UIViewController {

    @IBOutlet weak var userIdLabel: UILabel!
    @IBOutlet weak var menuItemTableView: UITableView!
    @IBOutlet weak var connectionStateImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        menuItemTableView.dataSource = self
        menuItemTableView.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if AppContext.shared.accessToken == "" {
            MenuItem.all = [.dashboard, .logs, .competition, .settings, .login, .termsAndPolicy]
            menuItemTableView.reloadData()
            userIdLabel.text = "You're not registered yet"
            userIdLabel.textColor = UIColor(hexString: "#AC281C")
        } else {
            MenuItem.all = [.dashboard, .logs, .competition, .settings, .logout, .termsAndPolicy]
            menuItemTableView.reloadData()
            userIdLabel.text = AppContext.shared.userCredentials.userName
            userIdLabel.textColor = UIColor(hexString: "#247EFC")
        }
        
        if let _ = AppContext.shared.bleManager.connectedPeripheral {
            connectionStateImageView.image = UIImage(named: "ic_connect")
        } else {
            connectionStateImageView.image = UIImage(named: "ic_disconnect")
        }
    }
}

extension SideMenuViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return MenuItem.all.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(for: indexPath) as SideMenuCell
        cell.menuTitleLabel.text = MenuItem.all[indexPath.row].rawValue
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let menuItem = MenuItem.all[indexPath.row]
        (slideMenuController() as! MainViewController).menuItemSelected(menu: menuItem)
    }
}
