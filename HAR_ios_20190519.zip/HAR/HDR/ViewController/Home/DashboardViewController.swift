//
//  DashboardViewController.swift
//  HDR
//
//  Created by Alex Chang on 4/4/19.
//  Copyright © 2019 alex. All rights reserved.
//

import UIKit

enum State {
    case normal
    case receiving
    case frozen
}

class DashboardViewController: UIViewController {

    @IBOutlet weak var numberContainerView: UIView!
    @IBOutlet weak var slotLabel: SlotLabel!
    @IBOutlet weak var unitLabel: UILabel!
    @IBOutlet weak var postButton: UIButton!
    @IBOutlet weak var resetButton: UIButton!
    @IBOutlet weak var shareDebugLogButton: UIButton!
    
    var unit: String = "Lbs" {
        didSet {
            unitLabel.text = unit
        }
    }
    
    var value: Float = 0.0 {
        didSet {
            slotLabel.animate(to: value.toString(integerDigits: 2, fractionDigits: 3))
        }
    }
    
    var lastValue: Float = 0.0
    var lastValueUpdateDate: Date = Date()
    
    var state: State = .normal {
        didSet {
            if state == .receiving {
                resetButton.isEnabled = false
                postButton.isEnabled = false
                resetButton.alpha = 0.5
                postButton.alpha = 0.5
            } else if state == .frozen {
                resetButton.isEnabled = true
                postButton.isEnabled = true
                resetButton.alpha = 1
                postButton.alpha = 1
            } else if value != 0.0 {
                resetButton.isEnabled = true
                postButton.isEnabled = true
                resetButton.alpha = 1
                postButton.alpha = 1
            } else {
                resetButton.isEnabled = false
                postButton.isEnabled = false
                resetButton.alpha = 0.5
                postButton.alpha = 0.5
            }
        }
    }
    
    var timer: Timer? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        postButton.layer.borderColor = UIColor.lightGray.cgColor
        postButton.layer.borderWidth = 2
        
        resetButton.layer.borderColor = UIColor.lightGray.cgColor
        resetButton.layer.borderWidth = 2
        
        shareDebugLogButton.layer.borderColor = UIColor.lightGray.cgColor
        shareDebugLogButton.layer.borderWidth = 2
        
        numberContainerView.layer.borderColor = UIColor.lightGray.cgColor
        numberContainerView.layer.borderWidth = 2
        
        slotLabel.horizontalAlignment = .center
        slotLabel.verticalAlignment = .center
        slotLabel.font = UIFont.systemFont(ofSize: 50)
        slotLabel.textColor = .white
        slotLabel.animationSpeed = 1.0
        slotLabel.text = "00.000"
        
        value = UserDefaults.standard.float(forKey: "HAR.FROZEN.VALUE")
        state = .normal
        
        AppContext.shared.bleManager.removeDelegate(self)
        AppContext.shared.bleManager.addDelegate(self)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        slotLabel.text = value.toString(integerDigits: 2, fractionDigits: 3)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        timer?.invalidate()
        timer = nil
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(checkFrozen), userInfo: nil, repeats: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        timer?.invalidate()
        timer = nil
        super.viewWillDisappear(animated)
    }
    
    @IBAction func menuButtonTapped(_ sender: Any) {
        openLeft()
    }
    
    @IBAction func postButtonTapped(_ sender: Any) {
        guard (slideMenuController() as? MainViewController)?.checkSignIn() ?? false else { return }
        
        rx.alert(title: "HangARat", message: "Post your results?", cancelTitle: nil, destructiveTitle: nil, otherTitles: ["YES", "NO"]).subscribe(onNext: { (style, index) in
            guard style == .default, index == 0 else { return }
            self.post()
        }).disposed(by: rx_disposeBag)
    }
    
    @IBAction func shareDebugLogButtonTapped(_ sender: Any) {
        let path = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("test.txt")
        do {
            let string = AppContext.shared.logoString
            try string.write(to: path, atomically: true, encoding: .utf8)
            let vc = UIActivityViewController(activityItems: [path], applicationActivities: [])
            vc.excludedActivityTypes = [
                UIActivity.ActivityType.assignToContact,
                UIActivity.ActivityType.mail,
                UIActivity.ActivityType.saveToCameraRoll,
                UIActivity.ActivityType.postToFlickr,
                UIActivity.ActivityType.postToVimeo,
                UIActivity.ActivityType.postToTencentWeibo,
                UIActivity.ActivityType.postToTwitter,
                UIActivity.ActivityType.postToFacebook,
                UIActivity.ActivityType.openInIBooks
            ]
            present(vc, animated: true, completion: nil)
            
            AppContext.shared.logoString = ""
        } catch {
            print("Failed to create file")
            print("\(error)")
        }
    }
    
    @IBAction func resetButtonTapped(_ sender: Any) {
        reset()
    }
    
    func reset() {
        lastValue = 0.0
        self.value = 0.0
        lastValueUpdateDate = Date()
        
        state = .normal
    }
    
    @IBAction func refreshButtonTapped(_ sender: Any) {
        let vc = HDRStoryboard.ScanScene.scanViewController.instantiate()
        UIApplication.shared.keyWindow?.rootViewController = vc
    }
    
    @objc func checkFrozen() {
        guard state != .frozen else { return }
        if self.value != 0.0, lastValue == self.value, Date().seconds(from: lastValueUpdateDate) > 2 {
            state = .frozen
            UserDefaults.standard.set(self.value, forKey: "HAR.FROZEN.VALUE")
            UserDefaults.standard.synchronize()
        }
    }
    
    func post() {
        let hud = showActivityHUD(message: "Posting...")
        
//        value = Float.random(in: 0..<20)
        
        APIManager.default.sendValue(value: "\(value)").subscribe { [weak self] evt in
            hud.hide(animated: true)
            
            switch evt {
            case .next:
                self?.reset()
                UserDefaults.standard.set(0.0, forKey: "HAR.FROZEN.VALUE")
                UserDefaults.standard.synchronize()
                self?.alertWithOK(message: "Post Complete")
            case .error(let error):
                self?.alertWithOK(message: error.errorMessage(message: "Failed posting value"))
            default:
                break
            }
        }.disposed(by: rx_disposeBag)
    }
}

extension DashboardViewController: BLEManagerDelegate {
    func bleStatusChanged(_ manager: BLEManagable, isAvailable: Bool) {
        if !isAvailable {
            alertWithOK(message: "HangARat Device Disconnected.")
        }
    }
    
    func bleManager(_ manager: BLEManagable, receivedData data: Data) {
        guard state != .frozen else { return }
        
        state = .receiving
        
//        self.value = (data as NSData).float.roundToPlaces(places: 3)
        
        guard let result = (data as NSData).stringUTF8 else { return }
        let results = result.split(separator: " ").map { String($0) }

        self.value = (Float(results[0]) ?? 0.0).roundToPlaces(places: 3)
//        self.unit = results[1]
        
        if self.value == 0.0 || lastValue != self.value {
            lastValue = self.value
            lastValueUpdateDate = Date()
        }
        
        let date = Date().toDateString(format: "yyyyMMdd-HH:mm:ss") ?? ""
        let log = "Did received data (\(date))\n\(result)\n\n"
        AppContext.shared.logoString += log
    }
    
    
}
