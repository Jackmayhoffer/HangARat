//
//  LogsViewController.swift
//  HDR
//
//  Created by Alex Chang on 4/6/19.
//  Copyright © 2019 alex. All rights reserved.
//

import UIKit

class LogsViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var logs: [ValueModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        tableView.dataSource = self
        tableView.delegate = self
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let hud = showActivityHUDTopMost()
        APIManager.default.getValues(mode: "INDIVIDUAL").subscribe { [weak self] evt in
            hud.hide(animated: true)
            switch evt {
            case .next(let json):
                self?.logs = json["values"].arrayValue.map{ ValueModel(json: $0) }.sorted { $0.createdAt > $1.createdAt }
                self?.tableView.reloadData()
            default:
                break
            }
        }.disposed(by: rx_disposeBag)
    }
    
    @IBAction func backButtonTapped(_ sender: Any) {
        _ = popViewController()
    }
    
    @IBAction func clearButtonTapped(_ sender: Any) {
        let hud = showActivityHUDTopMost()
        APIManager.default.clearWeights().subscribe { [weak self] evt in
            hud.hide(animated: true)
            self?.logs.removeAll()
            self?.tableView.reloadData()
        }.disposed(by: rx_disposeBag)
    }
    
}

extension LogsViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return logs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(for: indexPath) as LogsTableViewCell
        cell.noLabel.text = "\(indexPath.row + 1)"
        cell.valueModel = logs[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40.0
    }
}
