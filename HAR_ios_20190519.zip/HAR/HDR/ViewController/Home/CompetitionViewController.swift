//
//  CompetitionViewController.swift
//  HDR
//
//  Created by Alex Chang on 4/6/19.
//  Copyright © 2019 alex. All rights reserved.
//

import UIKit

class CompetitionViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var logs: [ValueModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        tableView.dataSource = self
        tableView.delegate = self
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let hud = showActivityHUDTopMost()
        APIManager.default.getValues(mode: "ALL").subscribe { [weak self] evt in
            hud.hide(animated: true)
            switch evt {
            case .next(let json):
                self?.logs = json["values"].arrayValue.map { ValueModel(json: $0) }.sorted { $0.recordValue > $1.recordValue }
                self?.tableView.reloadData()
            default:
                break
            }
            }.disposed(by: rx_disposeBag)
    }
    
    @IBAction func backButtonTapped(_ sender: Any) {
        _ = popViewController()
    }
    
}

extension CompetitionViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return logs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(for: indexPath) as CompetitionTableViewCell
        cell.noLabel.text = "\(indexPath.row + 1)"
        cell.valueModel = logs[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40.0
    }
}
