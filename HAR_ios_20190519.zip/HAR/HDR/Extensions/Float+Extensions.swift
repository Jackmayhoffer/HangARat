//
//  Float+Extensions.swift
//  GTF
//
//  Created by Alex on 2/9/2018.
//  Copyright © 2018 alex. All rights reserved.
//

import Foundation

extension Float {
    func roundToPlaces(places: Int) -> Float {
        let divisor = pow(10.0, Float(places))
        return Float((divisor * self).rounded() / divisor)
    }
    
    func toString(integerDigits: Int, fractionDigits: Int) -> String {
        let formatter = NumberFormatter()
        formatter.minimumFractionDigits = fractionDigits
        formatter.maximumFractionDigits = fractionDigits
        formatter.minimumIntegerDigits = integerDigits
        formatter.paddingPosition = .afterPrefix
        formatter.paddingCharacter = "0"
        return formatter.string(from: NSNumber(value: self))!
    }
}

extension Float64 {
    func toString(integerDigits: Int, fractionDigits: Int) -> String {
        let formatter = NumberFormatter()
        formatter.minimumFractionDigits = fractionDigits
        formatter.maximumFractionDigits = fractionDigits
        formatter.minimumIntegerDigits = integerDigits
        formatter.paddingPosition = .afterPrefix
        formatter.paddingCharacter = "0"
        return formatter.string(from: NSNumber(value: self))!
    }
}
