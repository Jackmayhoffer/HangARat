//
//  Data+Extensions.swift
//  HDR
//
//  Created by Alex Chang on 4/5/19.
//  Copyright © 2019 alex. All rights reserved.
//

import Foundation

// https://gist.github.com/tannernelson/73d0923efdee50e6c38f

func sizeof<T>(_ class: T.Type) -> Int {
    return  MemoryLayout<T>.size
}

extension NSData {
    var int: Int {
        get {
            var number: Int = 0
            self.getBytes(&number, length: sizeof(Int.self))
            return number
        }
    }
    
    var int8: Int8 {
        get {
            var number: Int8 = 0
            self.getBytes(&number, length: sizeof(Int8.self))
            return number
        }
    }
    
    var int16: Int16 {
        get {
            var number: Int16 = 0
            self.getBytes(&number, length: sizeof(Int16.self))
            return number
        }
    }
    
    var int32: Int32 {
        get {
            var number: Int32 = 0
            self.getBytes(&number, length: sizeof(Int32.self))
            return number
        }
    }
    
    var int64: Int64 {
        get {
            var number: Int64 = 0
            self.getBytes(&number, length: sizeof(Int64.self))
            return number
        }
    }
}

extension NSData {
    var uint: UInt {
        get {
            var number: UInt = 0
            self.getBytes(&number, length: sizeof(UInt.self))
            return number
        }
    }
    
    var uint8: UInt8 {
        get {
            var number: UInt8 = 0
            self.getBytes(&number, length: sizeof(UInt8.self))
            return number
        }
    }
    
    var uint16: UInt16 {
        get {
            var number: UInt16 = 0
            self.getBytes(&number, length: sizeof(UInt16.self))
            return number
        }
    }
    
    var uint32: UInt32 {
        get {
            var number: UInt32 = 0
            self.getBytes(&number, length: sizeof(UInt32.self))
            return number
        }
    }
}

extension NSData {
    var float: Float {
        get {
            var number: Float = 0.0
            self.getBytes(&number, length: sizeof(Float.self))
            return number
        }
    }
    
    var float32: Float32 {
        get {
            var number: Float32 = 0.0
            self.getBytes(&number, length: sizeof(Float32.self))
            return number
        }
    }
    
    var float64: Float64 {
        get {
            var number: Float64 = 0.0
            self.getBytes(&number, length: sizeof(Float64.self))
            return number
        }
    }
}

extension NSData {
    var uuid: NSUUID? {
        get {
            var bytes = [UInt8](repeating: 0, count: self.length)
            self.getBytes(&bytes, length: self.length * sizeof(UInt8.self))
            return NSUUID(uuidBytes: bytes)
        }
    }
}

extension NSData {
    var stringASCII: String? {
        get {
            return String(data: self as Data, encoding: .ascii)
        }
    }
    
    var stringUTF8: String? {
        get {
            return String(data: self as Data, encoding: .utf8)
        }
    }
}

extension Int {
    var data: NSData {
        var int = self
        return NSData(bytes: &int, length: sizeof(Int.self))
    }
}

extension UInt8 {
    var data: NSData {
        var int = self
        return NSData(bytes: &int, length: sizeof(UInt8.self))
    }
}

extension UInt16 {
    var data: NSData {
        var int = self
        return NSData(bytes: &int, length: sizeof(UInt16.self))
    }
}

extension UInt32 {
    var data: NSData {
        var int = self
        return NSData(bytes: &int, length: sizeof(UInt32.self))
    }
}

extension NSUUID {
    var data: NSData {
        var uuid = [UInt8](repeating: 0, count: 16)
        self.getBytes(&uuid)
        return NSData(bytes: &uuid, length: 16)
    }
}

extension String {
    var dataUTF8: NSData? {
        return self.data(using: .utf8) as NSData?
    }
    
    var dataASCII: NSData? {
        return self.data(using: .ascii) as NSData?
    }
}
