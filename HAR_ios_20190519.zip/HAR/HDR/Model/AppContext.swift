//
//  AppContext.swift
//  TalkingStatues
//
//  Created by Alex on 5/6/2018.
//  Copyright © 2018 alex. All rights reserved.
//

import Foundation

class AppContext: NSObject {
    static var shared = AppContext()
    
    static var keyValueStore = UserDefaults.standard
    
    var userCredentials: UserCredentials = {
        var credentials = UserCredentials(kvStore: AppContext.keyValueStore)
        credentials.load()
        return credentials
    }()
    
    var bleManager = BLEManager()
    var accessToken: String {
        set {
            userCredentials.accessToken = newValue
            userCredentials.save()
        }
        get {
            return userCredentials.accessToken
        }
    }
    
    var logoString = ""
    
    override init() {
        super.init()
        
    }
    
    func globalInit() {
        
    }
    
    deinit {
        
    }
}
