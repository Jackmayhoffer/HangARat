//
//  APIManager.swift
//  TalkingStatues
//
//  Created by Alex on 5/6/2018.
//  Copyright © 2018 alex. All rights reserved.
//

import Foundation
import Alamofire
import RxSwift
import RxAlamofire
import SwiftyJSON

class APIManager:BaseAPIManager {
    let manager:SessionManager
    
    static let `default` : APIManager = {
//        let configuration = URLSessionConfiguration.default
//        configuration.httpAdditionalHeaders = SessionManager.defaultHTTPHeaders
//        configuration.timeoutIntervalForRequest = 3600
//        let sessionManager = SessionManager(configuration: configuration)
//        return APIManager(manager: sessionManager)
        return APIManager(manager:SessionManager.default)
    }()
    
    init(manager:SessionManager){
        self.manager = manager
    }
}

extension APIManager {
    func signin(userName: String, password: String) -> Observable<JSON> {
        let params = ["UserName": userName,
                      "Password": password,
                      "Device": "iOS",
                      "Version": "1.0.0"]
        return post(.signin, parameters: params)
            .handleAPIResponse()
    }
    
    func signup(userName: String, email: String, password: String) -> Observable<JSON> {
        let params = ["UserName": userName,
                      "Email": email,
                      "Password": password]
        return post(.signup, parameters: params)
            .handleAPIResponse()
    }
    
    func forgotPassword(email: String) -> Observable<JSON> {
        let params = ["Email": email]
        return post(.forgotPassword, parameters: params)
            .handleAPIResponse()
    }
    
    func sendValue(value: String) -> Observable<JSON> {
        let params = ["AccessToken": AppContext.shared.accessToken,
                      "Value": value]
        return post(.sendvalue, parameters: params)
            .handleAPIResponse()
    }
    
    func getValues(mode: String) -> Observable<JSON> {
        let params = ["AccessToken": AppContext.shared.accessToken,
                      "Mode": mode]
        return post(.getvalue, parameters: params)
            .handleAPIResponse()
    }
    
    func clearWeights() -> Observable<JSON> {
        let params = ["AccessToken": AppContext.shared.accessToken]
        return post(.clearWeights, parameters: params)
            .handleAPIResponse()
    }

//    func login(email: String, password: String) -> Observable<JSON> {
//        return post(.login, parameters: ["email": email, "password": password])
//            .handleAPIResponse()
//            .map {
//                return $0["json"]
//        }
//    }
}
