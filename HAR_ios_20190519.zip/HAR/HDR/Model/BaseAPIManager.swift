//
//  APIManager.swift
//  TalkingStatues
//
//  Created by Alex on 5/6/2018.
//  Copyright © 2018 alex. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire
import SwiftyJSON
import RxAlamofire

protocol  BaseAPIManager {
    var manager: Alamofire.SessionManager { get }
}

extension BaseAPIManager {
    func post(_ url:APIURL, parameters params:[String:Any], encoding:ParameterEncoding = URLEncoding.default) -> Observable<JSON>{
        return manager.rx.responseData(.post, url, parameters: params, encoding: encoding)
            //        return manager.rx.responseData(.post, url)
            .flatMap { response -> Observable<(HTTPURLResponse, Data)> in
                
                #if isTesting
                guard url.path != APIURL.getChats.path else { return Observable.just(response) }
                let logText = JSON(data: response.1).description
                return self.manager.rx.responseData(.post, APIURL.log_error, parameters: ["api": url.path, "params": params.description, "result": logText], encoding: encoding)
                    .map { _ in response }
                #else
                return Observable.just(response)
                #endif
                
            }
            .map{
                //                Log.info(String(data: $1, encoding: .utf8))
                return JSON($1)
        }
    }
    
    func post(url: String, parameters params:[String:Any], encoding:ParameterEncoding = URLEncoding.default) -> Observable<JSON>{
        
        let _url = URL(string: url)
        return manager.rx.responseData(.post, _url!, parameters: params, encoding: encoding)
            .map{
                return JSON($1)
        }
    }
    
    func get(_ url:APIURL, parameters params:[String:Any], encoding:ParameterEncoding = URLEncoding.default) -> Observable<JSON>{
        return manager.rx.responseData(.get, url, parameters: params, encoding: encoding)
            .map{ JSON($1) }
    }
    
    func uploadImage(_ url: APIURL, parameters params:[String: Any], encoding:ParameterEncoding = URLEncoding.default, image: UIImage) -> Observable<JSON> {
        let uploadData = image.pngData()!
        return manager.upload(uploadData, to: url).rx.responseData().map { return JSON($1) }
    }
    
    func uploadMultipart(_ url: APIURL, parameters params:[String: Any], method: HTTPMethod = .post, encoding: ParameterEncoding = URLEncoding.default, image: UIImage? = nil, imageName: String = "photo", fileName: String = "photo_file.jpg") -> Observable<JSON> {
        let ob = Observable<JSON>.create { observer -> Disposable in
            self.manager.upload(
                multipartFormData: { multipartFormData in
                    if let _image = image {
                        multipartFormData.append(_image.jpegData(compressionQuality: 0.5)!, withName: imageName, fileName: fileName, mimeType: "image/jpeg")
                    }
                    for (key, value) in params {
                        multipartFormData.append(String(describing: value).data(using: .utf8)!, withName: key)
                    }
            },
                to: url,
                method: method,
                encodingCompletion: { result in
                    switch result {
                    case .success(let upload, _, _):
                        upload.responseData(completionHandler: { responseData in
                            observer.onNextAndCompleted(JSON(responseData.data!))
                        })
                    case let .failure(error):
                        observer.onError(error)
                    }
            })
            
            return Disposables.create()
        }
        return ob
    }
}

// MARK: - Invalid Session Handler
extension ObservableType where E == APIResponse {
    /**
     Hook api response and if error code for invalid session Id found, filter the signal and show invalid session screen.
     Also this will automatically sign out user.
     */
    func handleAPIResponse() -> Observable<JSON> {
        return
            filter{response in
                guard let err = APIError(response:response) else {
                    return true
                }
                
                print("Error code from response : \(err)")
                
                throw err
                }.map{
                    return $0.json!
        }
    }
}

// MARK: - Invalid Session Handler
extension ObservableType where E == JSON {
    /**
     Hook api response and if error code for invalid session Id found, filter the signal and show invalid session screen.
     Also this will automatically sign out user.
     */
    func handleAPIResponse() -> Observable<JSON> {
        return
            filter{ json in
                let response = APIResponse(json: json)
                guard let err = APIError(response:response) else {
                    return true
                }
                
                print("Error code from response : \(err)")
                
                throw err
            }
    }
}

struct APIResponse {
    var status = ""
    var code = -1
    var message = ""
    var json: JSON? = nil
    
    init() {
        
    }
    
    init(json: JSON) {
        code = json["ErrorCode"].intValue
        message = json["ErrorMessage"].stringValue
        self.json = json
    }
}
