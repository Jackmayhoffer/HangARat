//
//  ValueModel.swift
//  HDR
//
//  Created by Alex Chang on 4/6/19.
//  Copyright © 2019 alex. All rights reserved.
//

import Foundation
import SwiftyJSON

struct ValueModel {
    var userName = ""
    var recordValue: Float = 0.0
    var createdAt = ""
    
    init(json: JSON) {
        userName = json["UserName"].stringValue
        recordValue = json["Value"].floatValue
        createdAt = json["Created"].stringValue
    }
}
