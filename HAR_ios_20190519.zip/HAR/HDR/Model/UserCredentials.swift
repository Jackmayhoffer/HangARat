//
//  UserCredentials.swift
//  TalkingStatues
//
//  Created by Alex on 5/6/2018.
//  Copyright © 2018 alex. All rights reserved.
//

import Foundation

struct UserCredentials {
    enum Key: String, KVStoreKeyType, Hashable {
        case accessToken = "UserCredentials.User.AccessToken"
        case userName = "UserCredentials.User.UserName"
        case email = "UserCredentials.User.Email"
        
        var kvStoreKeyString: String {
            return rawValue
        }
        
        var hashValue: Int {
            return rawValue.hashValue
        }
    }
    
    var accessToken = ""
    var email = ""
    var userName = ""
    
    fileprivate let kvStore: KeyValueStoreType
    
    mutating func save() {
        kvStore.set(email, forKey: Key.email)
        kvStore.set(userName, forKey: Key.userName)
        kvStore.set(accessToken, forKey: Key.accessToken)
    }
    
    mutating func load() {
        email = kvStore.string(forKey: Key.email) ?? ""
        userName = kvStore.string(forKey: Key.userName) ?? ""
        accessToken = kvStore.string(forKey: Key.accessToken) ?? ""
    }
    
    mutating func delete() {
        email = ""
        accessToken = ""
        userName = ""
        
        self.save()
    }
    
    init(kvStore: KeyValueStoreType = EmptyKeyValueStore(), email: String = "", accessToken: String = "", userName: String = "") {
        self.kvStore = kvStore
        
        self.email = email
        self.accessToken = accessToken
        self.userName = userName
    }
}
