//
//  BLEManager.swift
//  MeasurementApp
//
//  Created by Alex on 8/6/2018.
//  Copyright © 2018 alex. All rights reserved.
//

import Foundation
import CoreBluetooth

private struct BLEConstants {
    // DISTO
//    static let DeviceService = CBUUID(string: "3ab10100-f831-4395-b29d-570977d5bf94")
//    static let DeviceCharacteristics = CBUUID(string: "3ab10101-f831-4395-b29d-570977d5bf94")
    
    // HAR
    static let DeviceService = CBUUID(string: "FFE0")
    static let DeviceCharacteristics = CBUUID(string: "FFE1")
}

private struct Weak<T: AnyObject> {
    weak var object: T?
}

protocol BLEManagable {
    func startScanning()
    func stopScanning()
    
    func addDelegate(_ delegate: BLEManagerDelegate)
    func removeDelegate(_ delegate: BLEManagerDelegate)
}

protocol BLEManagerDelegate: AnyObject {
    func bleStatusChanged(_ manager: BLEManagable, isAvailable: Bool)
    func bleManagerDidConnect(_ manager: BLEManagable)
    func bleManagerDidDisconnect(_ manager: BLEManagable)
    func bleManager(_ manager: BLEManagable, receivedData data: Data)
    func bleManagerFailedConnect(_ manager: BLEManagable)
}

extension BLEManagerDelegate {
    func bleStatusChanged(_ manager: BLEManagable, isAvailable: Bool) { }
    func bleManagerDidConnect(_ manager: BLEManagable) { }
    func bleManagerDidDisconnect(_ manager: BLEManagable) { }
    func bleManager(_ manager: BLEManagable, receivedData data: Data) { }
    func bleManagerFailedConnect(_ manager: BLEManagable) { }
}

class BLEManager: NSObject, BLEManagable {
    
    fileprivate var shouldStartScanning = false {
        didSet {
            bleDelegates().forEach { $0.bleStatusChanged(self, isAvailable: shouldStartScanning) }
        }
    }
    
    private var centralManager: CBCentralManager?
    private var isCentralManagerReady: Bool {
        get {
            guard let centralManager = centralManager else {
                return false
            }
            return centralManager.state != .poweredOff && centralManager.state != .unauthorized && centralManager.state != .unsupported
        }
    }
    
    fileprivate var connectingPeripheral: CBPeripheral?
    var connectedPeripheral: CBPeripheral?
    
    fileprivate var delegates: [Weak<AnyObject>] = []
    fileprivate func bleDelegates() -> [BLEManagerDelegate] {
        return delegates.compactMap { $0.object as? BLEManagerDelegate }
    }
    
    var preConnectedPeripheral: [CBPeripheral] = []
    var searchedPeripherals: [CBPeripheral] = []
    
    override init() {
        super.init()
        centralManager = CBCentralManager(delegate: self, queue: DispatchQueue.global(qos: .background))
        startScanning()
    }
    
    func startScanning() {
        guard let centralManager = centralManager, isCentralManagerReady == true else {
            return
        }
        
        preConnectedPeripheral = centralManager.retrieveConnectedPeripherals(withServices: [BLEConstants.DeviceService])
        searchedPeripherals.removeAll()
        
        if centralManager.state != .poweredOn {
            shouldStartScanning = true
        } else {
            shouldStartScanning = false
            centralManager.scanForPeripherals(withServices: nil, options: [CBCentralManagerScanOptionAllowDuplicatesKey : true])
//            centralManager.scanForPeripherals(withServices: [BLEConstants.ArduinoService], options: [CBCentralManagerScanOptionAllowDuplicatesKey : true])
        }
    }
    
    func stopScanning() {
        shouldStartScanning = false
        centralManager?.stopScan()
    }
    
    func addDelegate(_ delegate: BLEManagerDelegate) {
        delegates.append(Weak(object: delegate))
    }
    
    func removeDelegate(_ delegate: BLEManagerDelegate) {
        if let index = delegates.index(where: { $0.object === delegate }) {
            delegates.remove(at: index)
        }
    }
    
    func connectPeripheral(index: Int) {
        self.connectingPeripheral = searchedPeripherals[index]
        centralManager?.connect(searchedPeripherals[index], options: nil)
        self.stopScanning()
    }
    
    func connectPeripheral(peripheral: CBPeripheral) {
        self.connectingPeripheral = peripheral
        centralManager?.connect(peripheral, options: nil)
        self.stopScanning()
    }
    
    func disconnectCurrentConnection() {
        guard let peripheral = connectedPeripheral else { return }
        centralManager?.cancelPeripheralConnection(peripheral)
    }
}

// MARK: CBCentralManagerDelegate
extension BLEManager: CBCentralManagerDelegate {
    
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == .poweredOn {
            if self.shouldStartScanning {
                self.startScanning()
            }
        } else {
            self.connectingPeripheral = nil
            if let connectedPeripheral = self.connectedPeripheral {
                central.cancelPeripheralConnection(connectedPeripheral)
            }
            self.shouldStartScanning = true
        }
    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        
        let date = Date().toDateString(format: "yyyyMMdd-HH:mm:ss") ?? ""
        let peripheralName = peripheral.name ?? "Unknown"
        let log = "Did discover peripheral (\(date))\n\(peripheralName) \n\n"
        AppContext.shared.logoString += log
        
        guard !searchedPeripherals.contains(peripheral) else { return }
        searchedPeripherals.append(peripheral)
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        
        let date = Date().toDateString(format: "yyyyMMdd-HH:mm:ss") ?? ""
        let peripheralName = peripheral.name ?? "Unknown"
        let log = "Did connected to peripheral (\(date))\n\(peripheralName) \n\n"
        AppContext.shared.logoString += log
        
        self.connectedPeripheral = peripheral
        self.connectingPeripheral = nil
        
        peripheral.discoverServices([BLEConstants.DeviceService])
        peripheral.delegate = self
        
        self.informDelegatesDidConnect(manager: self)
    }
    
    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        let date = Date().toDateString(format: "yyyyMMdd-HH:mm:ss") ?? ""
        let peripheralName = peripheral.name ?? "Unknown"
        let log = "Failed to connect to peripheral (\(date))\n\(peripheralName) \n\n"
        AppContext.shared.logoString += log
        
        self.connectingPeripheral = nil
    }
    
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        let date = Date().toDateString(format: "yyyyMMdd-HH:mm:ss") ?? ""
        let peripheralName = peripheral.name ?? "Unknown"
        let log = "Did disconnect peripheral (\(date))\n\(peripheralName) \n\n"
        AppContext.shared.logoString += log
        
        self.connectedPeripheral = nil
        self.startScanning()
        self.informDelegatesDidDisconnect(manager: self)
    }
}

// MARK: CBPeripheralDelegate
extension BLEManager: CBPeripheralDelegate {
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if let services = peripheral.services {
            services.forEach {
                let date = Date().toDateString(format: "yyyyMMdd-HH:mm:ss") ?? ""
                let peripheralName = peripheral.name ?? "Unknown"
                let log = "Did discover service (\(date))\n\(peripheralName) - \($0.uuid.uuidString) \n\n"
                AppContext.shared.logoString += log
                
                peripheral.discoverCharacteristics(nil, for: $0)

            }
        }
        
//        if let service = peripheral.services?.filter ({ $0.uuid.uuidString.uppercased() == BLEConstants.DeviceService.uuidString.uppercased() }).first {
//            peripheral.discoverCharacteristics([BLEConstants.DeviceCharacteristics], for: service)
//        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        if let characteristics = service.characteristics {
            characteristics.forEach {
                if  $0.uuid.uuidString.uppercased() == BLEConstants.DeviceCharacteristics.uuidString.uppercased() {
                    peripheral.setNotifyValue(true, for: $0)
                }

                let date = Date().toDateString(format: "yyyyMMdd-HH:mm:ss") ?? ""
                let peripheralName = peripheral.name ?? "Unknown"
                let log = "Did discover characteristic (\(date))\n\(peripheralName) - \(service.uuid.uuidString) - \($0.uuid.uuidString)\n\n"
                AppContext.shared.logoString += log
            }
        }
        
//        if let characteristic = service.characteristics?.filter({ $0.uuid.uuidString.uppercased() == BLEConstants.DeviceCharacteristics.uuidString.uppercased()}).first {
//            peripheral.setNotifyValue(true, for: characteristic)
//        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        guard let data = characteristic.value else {
            return
        }
        
        self.informDelegatesDidReceiveData(manager: self, data: data)
    }
}

// MARK: Delegate Callbacks
extension BLEManager {
    
    func informDelegatesDidConnect(manager: BLEManager) {
        for delegate in self.bleDelegates() {
            DispatchQueue.main.async {
                delegate.bleManagerDidConnect(manager)
            }
        }
    }
    
    func informDelegatesFailedConnect(manager: BLEManager) {
        for delegate in self.bleDelegates() {
            DispatchQueue.main.async {
                delegate.bleManagerFailedConnect(manager)
            }
        }
    }
    
    func informDelegatesDidDisconnect(manager: BLEManager) {
        for delegate in self.bleDelegates() {
            DispatchQueue.main.async {
                delegate.bleManagerDidDisconnect(manager)
            }
        }
    }
    
    func informDelegatesDidReceiveData(manager: BLEManager, data: Data) {
        for delegate in self.bleDelegates() {
            DispatchQueue.main.async {
                delegate.bleManager(manager, receivedData: data)
            }
        }
    }
}
